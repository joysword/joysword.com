function ftoc(temperature){
    return parseInt((temperature-32)*5/9);
}
