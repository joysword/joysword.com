/*
 * CS525.Spring.2012 Project 2 Have you Seen the Saucers?
 * Written by Shi Yin Feb. 2012
 *
 * Based on original oclAndyGalaxy.cpp, qjulia galaxy.c, 2010 project by ekahle2
 *	and Heterogeneous Computing with OpenCL
 *
 */

//Includes

#include <memory>
#include <iostream>
#include <cassert>
#include <fstream>
#include <stdio.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mach/mach_time.h>

//OpenGL
#include "glew.h"
#include <OpenGL/OpenGL.h>
#include <OpenGL/CGLDevice.h>

//OpenCL
#include <OpenCL/opencl.h>

#ifdef __linux__
#include <GL/glut.h>
#endif

#ifdef __APPLE__
#include <GLUT/glut.h>
#endif

// Constants, defines, typedefs and global declarations
//*****************************************************************************
#define USE_GL_ATTACHMENTS              (0) // enable OpenGL attachments for Compute results
#define USE_GPU                         (1) 
#define DEBUG_INFO                      (0)
#define PAUSE							(1)
#define MAXNUMSAUCER					(5)
#define COMPUTE_KERNEL_FILENAME         ("/Users/joysword/Documents/cs525p3/p3/p3/gameoflife.cl")
#define VERTEX_SHADER_FILENAME			("/Users/joysword/Documents/cs525p3/p3/p3/gameoflife.vert")
#define FRAGMENT_SHADER_FILENAME		("/Users/joysword/Documents/cs525p3/p3/p3/gameoflife.frag")
#define GEOMETRY_SHADER_FILENAME		("/Users/joysword/Documents/cs525p3/p3/p3/gameoflife.geom")
#define TEXDIC							("/Users/joysword/Documents/cs525p3/p3/p3/")
#define COMPUTE_KERNEL_METHOD_NAME		("gameoflife")
#define SEPARATOR                       ("----------------------------------------------------------------------\n")

#define REFRESH_DELAY  0 //ms

#define WIDTH 1024
#define HEIGHT 768
#define DISTANCE 1000

#define RANDOM (0)
#define SQUARE (1)
#define SMALLRANDOM (2)

static int Width                        = WIDTH;
static int Height                       = HEIGHT;
static int Distance						= DISTANCE;

// game of life variables
int loadType = RANDOM; // how to seed cells - Shi
cl_mem output;
float Scale = 1; // the scale of the sphere - Shi
int rotation = 0; // if the sphere is ratating - Shi
int is3D = 1; // if render in 3D - Shi
float rotateAngle = 0; // rotate - Shi

// Rendering window vars
const unsigned int window_width = 1024;
const unsigned int window_height = 768;

const unsigned int image_width = 1024;
const unsigned int image_height = 768;

const int xmin = -2000; const int ymin = -2000; const int xmax = 2000; const int ymax = 2000;

// OpenCL vars
cl_uint numPlatforms = 0;
cl_platform_id *cpPlatforms = NULL;
cl_device_id cdDeviceId;
cl_uint uiDevCount = 0;
cl_device_type ComputeDeviceType;
cl_context cxContext;
cl_command_queue cqCmdQ;
size_t program_length;
const char* cSourceCL = NULL;             // Buffer to hold source for compilation 
cl_program cpProgram;
cl_kernel ckKernel;
cl_mem cl_membufferData;
cl_mem vbo_cl;
cl_int ciErrNum;
cl_event eventGlobal;

// GLSL vars
GLuint p;

// boid structure
struct Cells
{
	int pos[2];
};

// vbo variables
GLuint vbo;

unsigned int anim = 0;
unsigned int refresh = 1;
// mouse controls
int mouse_old_x, mouse_old_y;
int mouse_buttons = 0;
float rotate_x = 0.0, rotate_y = 0.0, rotate_z;
float translate_z = 0;

// keyboard controls
int spawnx, spawny;

// calculate fps
int frameCount = 0;
float currentTime = 0;
float previousTime = 0;
float fps;
char sz_temp[255];

// boids variables
float * h_particleData;

unsigned int displayMode = 2;
unsigned int timeMode = 0;
int pauseSimulation = PAUSE;
int spawnType = 0;
unsigned int reset_me = 0;

float targetX, targetY, targetZ;

Cells origCells[10000000];

int orignumCells = 0;
int numCells = 0;

//int nd = 7; //x, y, vx, vy, type, target, seeStrange

int computationHeight = 1;

// textures
//char * texData;
char texData[5000000];
GLuint texNumOn;
char texData2[5000000];
GLuint texNumOn2;
char texData3[5000000];
GLuint texNumOn3;

float  *texturePtr;
cl_mem  texturePtrLD;

// Forward Function declarations
//*****************************************************************************

// GL functionality
static void display();
// rendering callbacks
void keyboard(unsigned char key, int x, int y);
void mouse(int button, int state, int x, int y);
void motion(int x, int y);
static void reshape(int w, int h);
//void passiveMotion(int x, int y);
void timerEvent(int value);
void updatePos(int x);
void idle(void);

static int Initialize(int gpu);
	static int initGL();
	static int initCL(int);
	static int SetupComputeKernel();
		int convertToString(const char *filename, std::string &s);

void createVBO(GLuint* vbo);

void runKernel();

void doTexStuff(char * dataPath, char * fileName, int width, int height, char * TheArray);
void doTexStuff3(char * dataPath, char * fileName, int width, int height, char * TheArray);
int setupTexture(char * texData, int index);
int setupTexture(float * texData, int index);
void readTexture();
float mapVal(float value, float istart, float istop, float ostart, float ostop);
void drawText(char *text, float x, float y);
void calculateFPS();
//void runGame(int);

char *textFileRead(char *fn);
void printShaderLog(GLuint prog);
void printProgramLog(GLuint shad);
GLuint setShaders(char * vert, char * frag);
GLuint setShaders(char * vert, char * frag, char * geom);

// Seed Cells
//*****************************************************************************

void randomLoad()
{	
	orignumCells = 100000;
	
	readTexture();
	
	for (int i = 0; i < orignumCells; i++)
	{
		int tX = (rand() % image_width);
		int tY = (rand() % image_height);
		
		while (texturePtr[((image_height-1-tY)*image_width + (image_width-1-tX))] >= 0.005)
		{
			tX = (rand() % image_width);
			tY = (rand() % image_height);
		}
		
		origCells[i].pos[0] = tX;
		origCells[i].pos[1] = tY;
	}
	
	numCells = orignumCells;
}
void smallRandomLoad()
{
	orignumCells = 1000;
	
	readTexture();
	
	for (int i = 0; i < orignumCells; i++)
	{
		int tX = (rand() % 40) + Width / 2 - 40;
		int tY = (rand() % 40) + Height / 2 - 40;
		
		origCells[i].pos[0] = tX;
		origCells[i].pos[1] = tY;
	}
	
	numCells = orignumCells;
}
void squareLoad()
{
	for (int i = 0; i < orignumCells; i++)
	{
		
	}
}
void loadInCells()
{
	switch (loadType) {
		case SQUARE:
			squareLoad();
			break;
			
		case SMALLRANDOM:
			smallRandomLoad();
			break;
			
		default:
			randomLoad();
			break;
	}
}

//game of life example varibles
static const size_t board_size = Width * Height;
//static _Bool board[board_size];

// Main
//*****************************************************************************
int main( int argc, char** argv)
{	
	//loadInBoids();
	loadInCells();

	glutInit(&argc, argv);
	
	if (Initialize (USE_GPU) == GL_NO_ERROR)
	{
		printf("initialization succeeded!!\n");
		printf(SEPARATOR);
		
		printf("Creating VBO\n");
		createVBO(&vbo);
		printf("VBO Created\n");
		
		
		// Define a board from data just generated - Shi
		h_particleData = (float *) malloc (3*Width*Height*sizeof(float)); // r g b, 64*32 grids, float
		
		for (int i=0; i < 3 * Width * Height; i++) {
			h_particleData[i] = 0.0;
		}
		
		for (int pCounter = 0; pCounter < numCells; pCounter++)
		{
			int cx = origCells[pCounter].pos[0];
			int cy = origCells[pCounter].pos[1];
			h_particleData[3*(cy*Width+cx) + 1] = 1.0; //green = 1 - Shi
		}
		
		texturePtrLD = clCreateBuffer(cxContext, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, image_width*image_height*sizeof(float), texturePtr, &ciErrNum);
	
		// combine creation of memory on the device and copying values overs
		cl_membufferData = clCreateBuffer(cxContext, CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR, 3*Width*Height*sizeof(float), h_particleData, &ciErrNum);
		
		//cl_membufferData = clCreateBuffer(cxContext, CL_MEM_READ_WRITE, 3*Width*Height*sizeof(float), NULL, &ciErrNum);
		//ciErrNum = clEnqueueWriteBuffer(cqCmdQ, cl_membufferData, CL_TRUE, 0, 3*Width*Height*sizeof(float), h_particleData, 0, NULL, NULL);
		
		output = clCreateBuffer(cxContext, CL_MEM_WRITE_ONLY, 3*Width*Height*sizeof(float), NULL, &ciErrNum);
	
		//initialize map textures
		
		//doTexStuff((char *) "/Users/joysword/Documents/Projects/cs525p2test/", (char *) "pmap.raw", image_width, image_height, texData);
		//texNumOn = setupTexture(texData, 1);
		
		//doTexStuff((char *) TEXDIC, (char *) "map.raw", image_width, image_height, texData2);
		//texNumOn2 = setupTexture(texData2, 2);
		
		//char *textureData;

		// run opencl kernel
		runKernel();
		
		printf(SEPARATOR);
        printf("Starting event loop...\n");
		glutMainLoop();
	}
	return 0;
	
	//Cleanup(EXIT_SUCCESS);
}

// Initialize GL CL Kernel
//*****************************************************************************
static int Initialize(int gpu) {
    int err;
    err = initGL();
    if (err != GL_NO_ERROR) {
        printf ("Failed to setup OpenGL state!");
        exit (err);
    }
    err = initCL(gpu);
    if(err != CL_SUCCESS) {
        printf ("Failed to connect to compute device! Error %d\n", err);
        exit (err);
    }
    err = SetupComputeKernel();
    if (err != CL_SUCCESS) {
        printf ("Failed to setup compute kernel! Error %d\n", err);
        exit (err);
    }
    return CL_SUCCESS;
}

// Initialize GL
//*****************************************************************************
int initGL()
{
	// initialize GLUT 
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowPosition (glutGet(GLUT_SCREEN_WIDTH)/2 - window_width/2, 
                            glutGet(GLUT_SCREEN_HEIGHT)/2 - window_height/2);
	glutInitWindowSize(window_width, window_height);
	glutCreateWindow("GPU Project 3 - Shi | Game of Life");
	
	// register GLUT callback functions
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
	glutIdleFunc(idle);
	//glutReshapeFunc(reshape);
	//glutPassiveMotionFunc(passiveMotion);
	//glutTimerFunc(REFRESH_DELAY, timerEvent, 0);
	
	glewInit();
	
	glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_RECTANGLE_ARB);
	
    // default initialization
    glClearColor( 0.0, 0.0, 0.0, 1.0);
	
    // viewport
    glViewport( 0, 0, window_width, window_height);
	
	if (GLEW_ARB_vertex_shader && GLEW_ARB_fragment_shader && GLEW_EXT_geometry_shader4) //no problem
		printf("Ready for GLSL\n");
	else {
		printf("No GLSL support\n");
		exit(1);
	}
	
	p = setShaders((char *) VERTEX_SHADER_FILENAME, (char *) FRAGMENT_SHADER_FILENAME);
	//p = setShaders((char *) VERTEX_SHADER_FILENAME, (char *) FRAGMENT_SHADER_FILENAME, (char *) GEOMETRY_SHADER_FILENAME);
	
    // projection
	glMatrixMode(GL_PROJECTION);
    //glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	gluPerspective(45.0, (GLfloat)window_width / (GLfloat) window_height, 1.0, 50000); //field of view angle in y; aspect ratio; zNear; zFar

	gluLookAt(0.0, 0.0, Distance,
              0.0,0.0,0.0,
              0.0f,1.0f,0.0f);

	glGenTextures(1, &texNumOn);
	glActiveTexture(GL_TEXTURE0+0);
	
	return GL_NO_ERROR;
}

// Initialize CL
//*****************************************************************************
static int initCL(int gpu)
{
	size_t returned_size;
	ComputeDeviceType = gpu ? CL_DEVICE_TYPE_GPU : CL_DEVICE_TYPE_CPU;
	
    // Locate a compute device
    //
    ciErrNum = clGetDeviceIDs(NULL, ComputeDeviceType, 1, &cdDeviceId, NULL);
    if (ciErrNum != CL_SUCCESS)
    {
        printf("Error: Failed to locate compute device!\n");
        return EXIT_FAILURE;
    }
	
    // Create a context containing the compute device(s)
    //
    cxContext = clCreateContext(0, 1, &cdDeviceId, clLogMessagesToStdoutAPPLE, NULL, &ciErrNum);
    if (!cxContext)
    {
        printf("Error: Failed to create a compute context!\n");
        return EXIT_FAILURE;
    }
	
	unsigned int device_count;
    cl_device_id device_ids[16];
	
	ciErrNum = clGetContextInfo(cxContext, CL_CONTEXT_DEVICES, sizeof(device_ids), device_ids, &returned_size);
	
	if(ciErrNum)
    {
        printf("Error: Failed to retrieve compute devices for context!\n");
        return EXIT_FAILURE;
    }
	
	device_count = returned_size / sizeof(cl_device_id);
    
    int i = 0;
    int device_found = 0;
    cl_device_type device_type;
    for(i = 0; i < device_count; i++) 
    {
        clGetDeviceInfo(device_ids[i], CL_DEVICE_TYPE, sizeof(cl_device_type), &device_type, NULL);
        if(device_type == ComputeDeviceType) 
        {
            cdDeviceId = device_ids[i];
            device_found = 1;
            break;
        }	
    }
	
	if(!device_found) // CPU version failing here
    {
        printf("Error: Failed to locate compute device!\n");
        return EXIT_FAILURE;
    }
	
	for (int i=0;i<device_count;i++) {
		char buffer[10240];
		cl_uint buf_uint;
		cl_ulong buf_ulong;
		printf("%d OpenCL device(s) found on platform:\n", device_count);
		printf("=== %d ===\n", i+1);
		ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DEVICE_NAME, sizeof(buffer), buffer, NULL);
		printf("  DEVICE_NAME = %s\n", buffer);
		ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DEVICE_VENDOR, sizeof(buffer), buffer, NULL);
		printf("  DEVICE_VENDOR = %s\n", buffer);
		ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DEVICE_VERSION, sizeof(buffer), buffer, NULL);
		printf("  DEVICE_VERSION = %s\n", buffer);
		ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DRIVER_VERSION, sizeof(buffer), buffer, NULL);
		printf("  DRIVER_VERSION = %s\n", buffer);
		ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(buf_uint), &buf_uint, NULL);
		printf("  DEVICE_MAX_COMPUTE_UNITS = %u\n", (unsigned int)buf_uint);
		ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DEVICE_MAX_CLOCK_FREQUENCY, sizeof(buf_uint), &buf_uint, NULL);
		printf("  DEVICE_MAX_CLOCK_FREQUENCY = %u\n", (unsigned int)buf_uint);
		ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(buf_ulong), &buf_ulong, NULL);
		printf("  DEVICE_GLOBAL_MEM_SIZE = %llu\n", (unsigned long long)buf_ulong);
	}
	
	// Create a command queue
	cqCmdQ = clCreateCommandQueue(cxContext, cdDeviceId, CL_QUEUE_PROFILING_ENABLE, &ciErrNum);
	
	if (!cqCmdQ)
    {
        printf("Error: Failed to create a command queue!\n");
        return EXIT_FAILURE;
    }
	
	// Report the device vendor and device name
    // 
    cl_char vendor_name[1024] = {0};
    cl_char device_name[1024] = {0};
    ciErrNum = clGetDeviceInfo(cdDeviceId, CL_DEVICE_VENDOR, sizeof(vendor_name), vendor_name, &returned_size);
    ciErrNum |= clGetDeviceInfo(cdDeviceId, CL_DEVICE_NAME, sizeof(device_name), device_name, &returned_size);
    if (ciErrNum != CL_SUCCESS)
    {
        printf("Error: Failed to retrieve device info!\n");
        return EXIT_FAILURE;
    }
	
    printf(SEPARATOR);
    printf("Connecting to %s %s...\n", vendor_name, device_name);
	
    return CL_SUCCESS;
}

// Initialize Kernel
//*****************************************************************************
static int SetupComputeKernel(void)
{
    int err = 0;
	
    if (ckKernel) clReleaseKernel(ckKernel);    
    ckKernel = 0;
    if (cpProgram) clReleaseProgram(cpProgram);
    cpProgram = 0;
	
    printf(SEPARATOR);
    printf("Loading kernel source from file '%s'...\n", COMPUTE_KERNEL_FILENAME); 
	
	//load the kernel file
	std::string sourceStr;
	convertToString(COMPUTE_KERNEL_FILENAME, sourceStr);
	cSourceCL = sourceStr.c_str();
	
	cpProgram = clCreateProgramWithSource(cxContext, 1, (const char**) &cSourceCL, NULL, &ciErrNum);
	
	ciErrNum = clBuildProgram(cpProgram, 0, NULL, NULL, NULL, NULL);
	
    if (err != CL_SUCCESS)
    {
        size_t len;
        char buffer[2048];
		
        printf("Error: Failed to build program executable!\n");
        clGetProgramBuildInfo(cpProgram, cdDeviceId, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
        printf("%s\n", buffer);
        return EXIT_FAILURE;
    }
	
    // Create the compute kernel from within the program
    //
    printf("Creating kernel '%s'...\n", COMPUTE_KERNEL_METHOD_NAME);  
	
    ckKernel = clCreateKernel(cpProgram, COMPUTE_KERNEL_METHOD_NAME, &err);
    
	if (!ckKernel || err != CL_SUCCESS)
    {
        printf("Error: Failed to create compute kernel!\n");
        return EXIT_FAILURE;
    }	
    return CL_SUCCESS;
}

// Create VBO
//*****************************************************************************
void createVBO(GLuint* vbo)
{
	// create VBO
	unsigned int size_float = 8 * Width * Height * sizeof(float);
	
	 // create buffer object
	glGenBuffers(1, vbo);
	glBindBuffer(GL_ARRAY_BUFFER, *vbo);
	 
	 // initialize buffer object
	glBufferData(GL_ARRAY_BUFFER, size_float, 0, GL_DYNAMIC_DRAW);
	 
	// create standard OpenCL mem buffer
	vbo_cl = clCreateBuffer(cxContext, CL_MEM_WRITE_ONLY, 8 * Width * Height * sizeof(float), NULL, &ciErrNum);
}

// Run the OpenCL part of the computation
//*****************************************************************************
void runKernel()
{
	//int computationWidth = numCells/computationHeight;
	
	//size_t szGlobalWorkSize[] = {computationWidth, computationHeight};
    
    ciErrNum = CL_SUCCESS;
    
    // Set args and execute the kernel
	
	ciErrNum  = clSetKernelArg(ckKernel, 0, sizeof(cl_mem), (void *) &cl_membufferData);
	ciErrNum |= clSetKernelArg(ckKernel, 1, sizeof(cl_mem), (void *) &output);
	ciErrNum |= clSetKernelArg(ckKernel, 2, sizeof(cl_mem), &texturePtrLD);
	ciErrNum |= clSetKernelArg(ckKernel, 3, sizeof(cl_mem), (void *) &vbo_cl);
	ciErrNum |= clSetKernelArg(ckKernel, 4, sizeof(int), &Width);
	ciErrNum |= clSetKernelArg(ckKernel, 5, sizeof(int), &Height);
	ciErrNum |= clSetKernelArg(ckKernel, 6, sizeof(float), &Scale);
	ciErrNum |= clSetKernelArg(ckKernel, 7, sizeof(int), &rotation);
	if (rotation) rotateAngle += 0.01;
	ciErrNum |= clSetKernelArg(ckKernel, 8, sizeof(float), &rotateAngle);	
	ciErrNum |= clSetKernelArg(ckKernel, 9, sizeof(int), &is3D);
	
	//size_t workgroup_size;
    //ciErrNum = clGetKernelWorkGroupInfo(ckKernel, cdDeviceId, CL_KERNEL_WORK_GROUP_SIZE,
	//							   sizeof(size_t), &workgroup_size, NULL);
	
	// write current state (h_particleData) to the input buffer of kernel (cl_membufferData) - Shi
	//ciErrNum = clEnqueueWriteBuffer(cqCmdQ, cl_membufferData, CL_TRUE, 0, 3*Width*Height*sizeof(float), h_particleData, 0, NULL, NULL);
	
	// Run the kernel on every cell in the board
	ciErrNum = clEnqueueNDRangeKernel(cqCmdQ, ckKernel, 1, NULL, &board_size, NULL, 0, NULL, &eventGlobal);
	
    cl_ulong end, start;
    ciErrNum = clWaitForEvents(1, &eventGlobal);
    ciErrNum = clGetEventProfilingInfo(eventGlobal, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), &end, 0);
    ciErrNum |= clGetEventProfilingInfo(eventGlobal, CL_PROFILING_COMMAND_START, sizeof(cl_ulong), &start, 0);
    fprintf(stderr, "time in kernel: %0.2f ms\n",(end-start)*1.0e-6f);

    // map the PBO to copy data from the CL buffer via host
    glBindBufferARB(GL_ARRAY_BUFFER, vbo); 
    
    // map the buffer object into client's memory
    void* ptr = glMapBufferARB(GL_ARRAY_BUFFER, GL_WRITE_ONLY_ARB);
	
	// read ptr (vbo) from device vbo (vbo_cl) - Shi
	ciErrNum = clEnqueueReadBuffer(cqCmdQ, vbo_cl, CL_TRUE, 0, 8*Width*Height*sizeof(float), ptr, 0, NULL, NULL);
	
	// copy output to input for next iteration - Shi
	ciErrNum = clEnqueueCopyBuffer(cqCmdQ, output, cl_membufferData, 0, 0, 3*Width*Height*sizeof(float), 0, NULL, NULL);
	
	// read current state from output - Shi
	//ciErrNum = clEnqueueReadBuffer(cqCmdQ, output, CL_TRUE, 0, 3*Width*Height*sizeof(float), h_particleData, 0, NULL, NULL);
	
    glUnmapBufferARB(GL_ARRAY_BUFFER); 
}

// Display callback
//*****************************************************************************
static void display()
{
	GLint texLoc, effectLoc;
    int xgrid, ygrid, counter;
	
	anim += 1;
	refresh+=1;
    
    // set view matrix
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    //glRotatef(rotate_x, 1.0, 0.0, 0.0);
    //glRotatef(rotate_y, 0.0, 1.0, 0.0);
    glTranslatef(rotate_y, -rotate_x, translate_z);
	
	// by default draw a white polygon if the texturing doesn't work.
    glColor3f(1.0, 0.0, 1.0);
    counter = 0;
	
	
	if (displayMode == 1)
	{
		glEnable(GL_DEPTH_TEST);
		// set the texture parameters
		glBindTexture( GL_TEXTURE_2D, texNumOn);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		
		glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGB, Width, Height, 0, GL_RGB, GL_FLOAT, (const GLvoid *) h_particleData);
		
		//glEnable(GL_TEXTURE_2D);
		glEnable(GL_TEXTURE_RECTANGLE_ARB);
		
		// bind the current state (h_particleData) to a texture - Shi
		//texNumOn = setupTexture(h_particleData, 0);
		
		//glBindTexture(GL_TEXTURE_2D, texNumOn);
		glBindTexture(GL_TEXTURE_RECTANGLE_ARB, texNumOn);

		// use the shader
		glUseProgram(p);
		
		// always using texture 0 for now
		texLoc = glGetUniformLocation(p, "whichTexture");
		glUniform1i(texLoc, 0);
		
			// draw praticles 通过 texture
		glBegin( GL_POLYGON );    
		// GL_TEXTURE_RECTANGLE_ARB uses pixel coordinates rather than the standard OpenGL 0.0 to 1.0
		//glTexCoord2f( 0.0f, 1.0f );
		glTexCoord2i(0, Height);
		glVertex3i( -Width/2, Height/2, 0.0f );
		
		//glTexCoord2f( 1.0f, 1.0f ); 
		glTexCoord2i(Width, Height);
		glVertex3i(  Width/2, Height/2, 0.0f );
		
		//glTexCoord2f( 1.0f, 0.0f );
		glTexCoord2i(Width, 0);
		glVertex3i(  Width/2, -Height/2, 0.0f );
		
		//glTexCoord2f( 0.0f, 0.0f ); 
		glTexCoord2i(0, 0);
		glVertex3i( -Width/2, -Height/2, 0.0f );
		glEnd();
		
	}
	else if (displayMode == 2)
	{
		glEnable(GL_DEPTH_TEST);
		// draw paticles 通过 vbo
		
		glBindBuffer(GL_ARRAY_BUFFER, vbo);
		glVertexPointer(4, GL_FLOAT, 0, 0);
		glColorPointer(4, GL_FLOAT, 0, (GLvoid *) (4 * Width * Height * sizeof(float)));
		
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_COLOR_ARRAY);

		glPointSize(2.0);
		glDrawArrays(GL_POINTS, 0, Width * Height);
		
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
	}
	
	glDisable(GL_DEPTH_TEST);
	sprintf(sz_temp, "FPS: %4.2f", fps);
	drawText(sz_temp , -520, -400);
	/*
	int sss = (int)mapVal(1235, 0, image_width-1, xmin, xmax);
	int ttt = (int)mapVal(985, 0, image_height-1, ymax, ymin);
	glBegin(GL_POINTS);

		glColor3f(1.0,1.0,1.0);
	for (int i=-10+sss;i<10+sss;i++)
	{
		for (int j=-10+ttt; j<10+ttt; j++) {
			glVertex3f(i,j,0.0);
		}
	}
	glEnd();*/

/*
	glBegin(GL_POINTS);
	for (int y=0;y<Height;y++)
	{
		for (int x=0;x<Width;x++)
		{
			glColor3f(h_particleData[3*(y*Width+x)+0], h_particleData[3*(y*Width+x)+1], h_particleData[3*(y*Width+x)+2]);
			glVertex2i(x - Width/2, y - Height/2);
		}
	}
	glEnd();
*/
	// run OpenCL kernel to generate vertex positions
	if (!pauseSimulation)
	{
		runKernel();
	}
	
	// flip backbuffer to screen
    glutSwapBuffers();
	//glutPostRedisplay();
}

void timerEvent(int value)
{
	calculateFPS();
	glutPostRedisplay();
	glutTimerFunc(REFRESH_DELAY, timerEvent,0);
}

static void reshape (int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glClear(GL_COLOR_BUFFER_BIT);
    glutSwapBuffers();
    
    //Width = w;
    //Height = h;    
}

// Keyboard events handler
//*****************************************************************************
void keyboard( unsigned char key, int x, int y)
{
    switch(key) 
    {
        case 27:
            // Cleanup up and quit
            //bNoPrompt = true;
			//Cleanup(EXIT_SUCCESS);
			exit(0);
		case ' ':
			pauseSimulation = !pauseSimulation;
			break;
		case '1':
			displayMode = 1;
			break;
		case '2':
			displayMode = 2;
			break;
		case 'a':
			Scale += 0.05;
			break;
		case 'z':
			Scale -= 0.05;
			break;
		case 'm':
			Scale = 1;
			rotate_x = 0;
			rotate_y = 0;
			translate_z = 0;
			break;
		case 'r':
			rotation = !rotation;
			break;
		case 'p':
			is3D = !is3D;
			break;
	}
}

// Mouse event handlers
//*****************************************************************************
void mouse(int button, int state, int x, int y)
{
    if (state == GLUT_DOWN) {
        mouse_buttons |= 1<<button;
    } else if (state == GLUT_UP) {
        mouse_buttons = 0;
    }
	
    mouse_old_x = x;
    mouse_old_y = y;
    //glutPostRedisplay();
}

void motion(int x, int y)
{
    float dx, dy;
    dx = (float)(x - mouse_old_x);
    dy = (float)(y - mouse_old_y);
	
    if (mouse_buttons & 1) {
        rotate_x += dy * 10;
        rotate_y += dx * 10;
    } else if (mouse_buttons & 4) {
		translate_z += dy * 3;
	}
	
    mouse_old_x = x;
    mouse_old_y = y;
}

// Calculate FPS
//*****************************************************************************
void calculateFPS()
{
    //  Increase frame count
    frameCount++;
	
    //  Get the number of milliseconds since glutInit called
    //  (or first call to glutGet(GLUT ELAPSED TIME)).
    currentTime = glutGet(GLUT_ELAPSED_TIME);
	
    //  Calculate time passed
    int timeInterval = currentTime - previousTime;
	
    if(timeInterval > 1000)
    {
        //  calculate the number of frames per second
        fps = frameCount / (timeInterval / 1000.0f);
		
        //  Set time
        previousTime = currentTime;
		
        //  Reset frame count
        frameCount = 0;
    }
}

void idle()
{
	calculateFPS();
	glutPostRedisplay();
}

// Other stuff
//*****************************************************************************
int convertToString(const char *filename, std::string &s)
{
	size_t size;
	char* str;
	
	std::fstream f(filename, (std::fstream::in | std::fstream::binary));
	
	//fstream f(filename, (fstream::in | fstream::binary));
	
	if(f.is_open())
	{
		size_t fileSize;
		f.seekg(0, std::fstream::end);
		size = fileSize = (size_t)f.tellg();
		f.seekg(0, std::fstream::beg);
		
		str = new char[size+1];
		if(!str)
		{
			f.close();
			return NULL;
		}
		
		f.read(str, fileSize);
		f.close();
		str[size] = '\0';
		
		s = str;
		delete[] str;
		return 0;
	}
	printf("Error: Failed to open file %s\n", filename);
	return 1;
}

int setupTexture(char * texData, int index)
{
    //static int textureNum = 0;
	
    glBindTexture(GL_TEXTURE_2D, index);
	
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image_width, image_height, 0, GL_RGB,
				 GL_UNSIGNED_BYTE, (const GLvoid *) texData);
	
	//glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
	
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	
    //textureNum++;
	
    return(index);
}

int setupTexture(float * texData, int index)
{
    //static int textureNum = 0;
	
    glBindTexture(GL_TEXTURE_2D, index);
	
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Width, Height, 0, GL_RGB,
				 GL_FLOAT, (const GLvoid *) texData);
	
	//glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
	
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	
    //textureNum++;
	
    return(index);
}

void doTexStuff(char * dataPath, char * fileName, int width, int height,
				char * TheArray)
{
    char fullPath[256];
    FILE * imageFile;
	
    strcpy(fullPath, dataPath);
    strcat(fullPath, fileName);
    imageFile = fopen(fullPath, "r");
	
    if (imageFile == NULL) 
		fprintf(stderr,"Cannot find texture file in data directory\n");
    else
	{
        fread(TheArray, sizeof(char), height*width*3, imageFile);
        fclose(imageFile);
	}
}

void doTexStuff3(char * dataPath, char * fileName, int width, int height,
				char * TheArray)
{
    char fullPath[256];
    FILE * imageFile;
	
    strcpy(fullPath, dataPath);
    strcat(fullPath, fileName);
    imageFile = fopen(fullPath, "r");
	
    if (imageFile == NULL) 
		fprintf(stderr,"Cannot find texture file in data directory\n");
    else
	{
        fread(TheArray, sizeof(char), height*width, imageFile);
        fclose(imageFile);
	}
}

void readTexture()
{
    unsigned char *Braw;
	FILE *stream;	
	if((stream = fopen("/Users/joysword/Documents/cs525p3/p3/p3/map.raw", "rb"))==NULL)
	{
		printf("Error while loading data from file %s.\n","map.raw");
		exit(0);
	}
	else
	{
		Braw = (unsigned char *)malloc(image_width*image_height);
		
		fread(Braw, sizeof(unsigned char),image_width*image_height, stream);
	}
	fclose( stream );
	
	texturePtr = (float *)malloc(image_width*image_height*sizeof(float));
	
	for(int i = 0 ;i< image_height;i++){
		for(int j = 0 ;j<image_width;j++){
			texturePtr[i*image_width+j] =   Braw[i*image_width+j]/255.0f;
			//printf("%f\n",(texturePtr[i*image_width+j]));
		}
	}
}

float mapVal(float value, float istart, float istop, float ostart, float ostop ){
	
	return ostart + (ostop - ostart) * ((value - istart) / (istop - istart)); 
}

void drawText(char *text, float x, float y)
{
	int i; 
	int size  = strlen(text);
	
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -1.0f);
	glRasterPos2f(x, y);
	
	for (i = 0; i < size; i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text[i]);
	}
}

////////////////SHADERS STUFF//////////////////
char *textFileRead(char *fn)
{
	FILE *fp;
	char *content = NULL;
	
	int count=0;
	
	if (fn != NULL) {
		fp = fopen(fn,"rt");
		
		if (fp != NULL) {
			
			fseek(fp, 0, SEEK_END);
			count = ftell(fp);
			rewind(fp);
			
			if (count > 0) {
				content = (char *)malloc(sizeof(char) * (count+1));
				count = fread(content,sizeof(char),count,fp);
				content[count] = '\0';
			}
			fclose(fp);
		}
	}
	
	if (content == NULL)
	{
		fprintf(stderr, "ERROR: could not load in file %s\n", fn);
		exit(1);
	}
	return content;
}

void printShaderLog(GLuint prog)
{
    GLint infoLogLength = 0;
    GLsizei charsWritten  = 0;
    GLchar *infoLog;
	
    glGetShaderiv(prog, GL_INFO_LOG_LENGTH, &infoLogLength);
	
    if (infoLogLength > 0)
    {
        infoLog = (char *) malloc(infoLogLength);
        glGetShaderInfoLog(prog, infoLogLength, &charsWritten, infoLog);
		printf("%s\n",infoLog);
        free(infoLog);
    }
}

void printProgramLog(GLuint shad)
{
    GLint infoLogLength = 0;
    GLsizei charsWritten  = 0;
    GLchar *infoLog;
	
    glGetProgramiv(shad, GL_INFO_LOG_LENGTH, &infoLogLength);
	
    if (infoLogLength > 0)
    {
        infoLog = (char *) malloc(infoLogLength);
        glGetProgramInfoLog(shad, infoLogLength, &charsWritten, infoLog);
		printf("%s\n",infoLog);
        free(infoLog);
    }
}

GLuint setShaders(char * vert, char * frag) {
    GLuint v, f, pro;
	char *vs,*fs;
	
	v = glCreateShader(GL_VERTEX_SHADER);
	f = glCreateShader(GL_FRAGMENT_SHADER);
	
	vs = textFileRead(vert);
	fs = textFileRead(frag);
		
	const char * vv = vs;
	const char * ff = fs;
	
	glShaderSource(v, 1, &vv, NULL);
	glShaderSource(f, 1, &ff, NULL);
	
	free(vs);
	free(fs);
	
	glCompileShader(v);
	glCompileShader(f);
	
	printShaderLog(v);
	printShaderLog(f);
	
	pro = glCreateProgram();
	glAttachShader(pro,v);
	glAttachShader(pro,f);
	
	glLinkProgram(pro);
	printProgramLog(pro);
	
	return(pro);
}

GLuint setShaders(char * vert, char * frag, char * geom) {
    GLuint v, f, g, pro;
	char *vs,*fs, *gs;
	
	v = glCreateShader(GL_VERTEX_SHADER);
	f = glCreateShader(GL_FRAGMENT_SHADER);
	g = glCreateShader(GL_GEOMETRY_SHADER);
	
	vs = textFileRead(vert);
	fs = textFileRead(frag);
	gs = textFileRead(geom);
	
	//std::string shadersourceStr;
	//convertToString(VERTEX_SHADER_FILENAME, shadersourceStr);
	
	//vs = (char *) shadersourceStr.c_str();
	
	const char * vv = vs;
	const char * ff = fs;
	const char * gg = gs;
	
	glShaderSource(v, 1, &vv, NULL);
	glShaderSource(f, 1, &ff, NULL);
	glShaderSource(g, 1, &gg, NULL);
	
	free(vs);
	free(fs);
	free(gs);
	
	glCompileShader(v);
	glCompileShader(f);
	glCompileShader(g);
	
	printShaderLog(v);
	printShaderLog(f);
	printShaderLog(g);
	
	pro = glCreateProgram();
	glAttachShader(pro,v);
	glAttachShader(pro,f);
	glAttachShader(pro,g);
	
	glLinkProgram(pro);
	printProgramLog(pro);
	
	return(pro);
}