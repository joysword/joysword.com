///////////////////////////////////////////////////////////
//
// simple OpenCV and GLSL demo program for CS 525 GPU Programming
// 
// Written by Andy Johnson 12/11
// Editted by Shi Yin 01/12
// originally based off the Lighthouse 3D tutorials
///////////////////////////////////////////////////////////

// move these 4 general headers to the top to avoid redefinition of exit() - Shi
// in fact this problem is only in Windows, Mac OSX is OK - Shi

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "GL/glew.h"

#ifdef __linux__
#include <GL/glut.h>
#endif

#ifdef __APPLE__
#include <glut.h>
#endif

#ifdef _WIN32
#include "glut.h"
#endif

#include "cv.h"
#include "highgui.h"

#include "header.h"

#define IMAGE_SIZE 800

int winWidth = IMAGE_SIZE;
int winHeight = IMAGE_SIZE;

GLuint frame; //deleted useless chosenTex - Shi

// openCV stuff
IplImage *image = 0;
IplImage *destination = 0;
IplImage * showMe;

GLuint cameraImageTextureID = 0;
CvCapture *capture = 0;

// new stuff - Shi
char mode = 'z';
int currentWindow = 0; // 0 for first page, 1 for second and 2 for last - Shi

float rotAmount = 0;

float mouseWindowX = 0.0;
float mouseWindowY = 0.0;

////////////////////////////////////////////////////////////////////////////////

char *textFileRead(char *fn)
{
	FILE *fp;
	char *content = NULL;

	int count=0;

	if (fn != NULL) {
		fp = fopen(fn,"rt");

		if (fp != NULL) {
      
			fseek(fp, 0, SEEK_END);
			count = ftell(fp);
			rewind(fp);

			if (count > 0) {
				content = (char *)malloc(sizeof(char) * (count+1));
				count = fread(content,sizeof(char),count,fp);
				content[count] = '\0';
			}
			fclose(fp);
		}
	}
	
	if (content == NULL)
	   {
	   fprintf(stderr, "ERROR: could not load in file %s\n", fn);
	   exit(1);
	   }
	return content;
}                    

////////////////////////////////////////////////////////////////////////////////

GLuint p; // deleted useless p2 - Shi

//float lpos[4] = {1.0, 0.5, 1.0, 0.0}; don't need this - Shi

void changeSize(int w, int h) {
	
	if(h == 0)
		h = 1;

	float ratio = 1.0 * winWidth / winHeight;

	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	winWidth = w; //winWidth;
	winHeight = h; // winHeight;
	
	// Set the viewport to be the entire window
    glViewport(0, 0, winWidth, winHeight);

	// Set the correct perspective.
	gluPerspective(45, ratio, 1, 1000);
	glMatrixMode(GL_MODELVIEW);
}
	
////////////////////////////////////////////////////////////////////////////////
void printShaderLog(GLuint prog)
{
    GLint infoLogLength = 0;
    GLsizei charsWritten  = 0;
    GLchar *infoLog;

    glGetShaderiv(prog, GL_INFO_LOG_LENGTH, &infoLogLength);

    if (infoLogLength > 0)
    {
        infoLog = (char *) malloc(infoLogLength);
        glGetShaderInfoLog(prog, infoLogLength, &charsWritten, infoLog);
		printf("%s\n",infoLog);
        free(infoLog);
    }
}

void printProgramLog(GLuint shad)
{
    GLint infoLogLength = 0;
    GLsizei charsWritten  = 0;
    GLchar *infoLog;

    glGetProgramiv(shad, GL_INFO_LOG_LENGTH, &infoLogLength);

    if (infoLogLength > 0)
    {
        infoLog = (char *) malloc(infoLogLength);
        glGetProgramInfoLog(shad, infoLogLength, &charsWritten, infoLog);
		printf("%s\n",infoLog);
        free(infoLog);
    }
}

// draw the window - Shi
inline void drawPolygon(float xmin, float ymin, float xmax, float ymax)
{
	glBegin(GL_POLYGON);
			glTexCoord2i(0, showMe->height);
			glVertex3f(xmin, ymin, 0.0f);

			glTexCoord2i(showMe->width, showMe->height);
			glVertex3f(xmax, ymin, 0.0f);

			glTexCoord2i(showMe->width, 0);
			glVertex3f(xmax, ymax, 0.0f);

			glTexCoord2i(0, 0);
			glVertex3f(xmin, ymax, 0.0f);
	glEnd();
}

void renderScene(void) {

	GLint texLoc, effectLoc;
    int xgrid, ygrid, counter;

	// new stuff - Shi
	GLint lightLoc, tangentLoc, noiseLoc;
	
    // openCV stuff
    IplImage *frame = 0;
    frame = cvQueryFrame(capture);

	// If I can't get a frame then exit the program
	if(!frame) exit(1);

	// create a guaranteed texture size
	destination = cvCreateImage(cvSize(800, 800), frame->depth, frame->nChannels);
	cvResize(frame, destination);

	// set the texture parameters
	glBindTexture(GL_TEXTURE_2D, cameraImageTextureID); //bind the texture to it's array
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

	showMe = destination;

	if(showMe->nChannels == 3)
	{
		glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGB, showMe->width, showMe->height, 0, GL_BGR, GL_UNSIGNED_BYTE, showMe->imageData);
	} 
	else if(frame->nChannels == 4)
	{
		glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGBA, showMe->width, showMe->height, 0, GL_BGRA, GL_UNSIGNED_BYTE, showMe->imageData);
	}
	
	// change window title to give users feedback! - Shi
	if (currentWindow == 0)
	{
		if (mode == 'z')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Window 1");
		}
		else if (mode == 'q')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Untouched");
		}
		else if (mode == 'a')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Two Face");
		}
		else if (mode == 'w')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Privacy");
		}
		else
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | For the Record");
		}
	}
	else if (currentWindow == 1)
	{
		if (mode == 'z')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Window 2");
		}
		else if (mode == 'q')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Untouched");
		}
		else if (mode == 'a')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Just Like Old Times");
		}
		else if (mode == 'w')
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | Spring Bump Festival");
		}
		else
		{
			glutSetWindowTitle("GPU Programming-P1 - Yin | See Me on The Teapot");
		}
	}
	else if (currentWindow == 2)
	{
		glutSetWindowTitle("GPU Programming-P1 - Yin | Window 3");
	}
	
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();
	
	glBindTexture(GL_TEXTURE_RECTANGLE_ARB, cameraImageTextureID);
	glBindTexture(GL_TEXTURE_3D, noise3DTexName);

	// use the shader
	glUseProgram(p);
	
    texLoc = glGetUniformLocation(p, "whichTexture");
    glUniform1i(texLoc, 0);

	tangentLoc = glGetAttribLocation(p, "Tangent");
    glVertexAttrib3f(tangentLoc, 1.0, 0.0, 0.0);
	
	lightLoc = glGetUniformLocation(p, "LightPosition");
	glUniform3f(lightLoc, 1.0, 1.0, 4.0);

	noiseLoc = glGetUniformLocation(p, "Noise");
	glUniform1i(noiseLoc, 1);

	// by default draw a white polygon if the texturing doesn't work.
    glColor3f(1.0, 1.0, 1.0);
    counter = 0;   
    
	// draw upper left image - Shi
	if (mode == 'q')
	{
		gluLookAt(0.0,0.0,5.0, 
		      0.0,0.0,-1.0,
			  0.0f,1.0f,0.0f);
		effectLoc = glGetUniformLocation(p, "whichEffect");
		glUniform1i(effectLoc, 1 + 4 * currentWindow);
		
		drawPolygon(-2.0f, -2.0f, 2.0f, 2.0f);
	}
	// draw upper right image - Shi
	else if (mode == 'w')
	{
		
			gluLookAt(0.0,0.0,5.0,
		      0.0,0.0,-1.0,
			  0.0f,1.0f,0.0f);
		
		if (currentWindow == 1)
		// draw bump mapping - Shi
		{
			glRotatef(rotAmount, 0, 1, 0);
			effectLoc = glGetUniformLocation(p, "whichEffect");
			glUniform1i(effectLoc, 3 + 4 * currentWindow);
		
			drawPolygon(-1.5f, -1.5f, 1.5f, 1.5f);
		}
		else
		{
			effectLoc = glGetUniformLocation(p, "whichEffect");
			glUniform1i(effectLoc, 3 + 4 * currentWindow);
		
			drawPolygon(-2.0f, -2.0f, 2.0f, 2.0f);
		}
	}
	// draw lower left image - Shi
	else if (mode == 'a')
	{
		gluLookAt(0.0,0.0,5.0, 
		      0.0,0.0,-1.0,
			  0.0f,1.0f,0.0f);
		effectLoc = glGetUniformLocation(p, "whichEffect");
		glUniform1i(effectLoc, 0 + 4 * currentWindow);

		drawPolygon(-2.0f, -2.0f, 2.0f, 2.0f);
	}
	// draw lower right image - Shi
	else if (mode == 's')
	{
		
		if (currentWindow == 1)
		// draw environment mapping - Shi
		{
			gluLookAt(0.0,3.0,6.0, 
		      0.0,0.0,-1.0,
			  0.0f,1.0f,0.0f);
			effectLoc = glGetUniformLocation(p, "whichEffect");
			glUniform1i(effectLoc, 6);

			glRotatef(mouseWindowX*90+90,0,1,0);
			glRotatef(mouseWindowY*90,0,0,1);

			glutSolidTeapot(1);
		}
		else
		{
			gluLookAt(0.0,0.0,5.0, 
		      0.0,0.0,-1.0,
			  0.0f,1.0f,0.0f);
			effectLoc = glGetUniformLocation(p, "whichEffect");
			glUniform1i(effectLoc, 2 + 4 * currentWindow);

			drawPolygon(-2.0f, -2.0f, 2.0f, 2.0f);
		}
	}
	// show all images
	else if (mode == 'z')
	{
		gluLookAt(0.0,0.0,5.0, 
						0.0,0.0,-1.0,
						0.0f,1.0f,0.0f);
		for (xgrid=0; xgrid<2; xgrid++)
		{
    		for (ygrid=0; ygrid<2; ygrid++)
			{
					// pick the effect to use

					//get the location of Uniform 'whichEffect' and specify it equal to counter - Shi
					effectLoc = glGetUniformLocation(p, "whichEffect");
					glUniform1i(effectLoc, counter + 4 * currentWindow);
					counter++;

					// draw the polygon with the current texture and effect
				
					drawPolygon(-2.0+2*xgrid, -2.0+2*ygrid, 0.0+2*xgrid, 0.0+2*ygrid);
			}
		}
	}

	rotAmount += 1.5;
	glutSwapBuffers();
}

/////////////////////////process keyboard control////////////////////////////// - Shi
void processNormalKeys(unsigned char key, int x, int y) {

	// exit program
	if (key == 27) 
		exit(0);

	// keyboard control - Shi
	if (key == 'a' || key == 'A')
	{
		mode = 'a';
	}
	else if (key == 'q' || key == 'Q')
	{
		mode = 'q';
	}
	else if (key == 's' || key == 'S')
	{
		mode = 's';
	}
	else if (key == 'w' || key == 'W')
	{
		mode = 'w';
	}
	else if (key == 'z' || key == 'Z')
	{
		mode = 'z';
	}

	if (key == '2')
	{
		currentWindow = 1; mode = 'z';
	}
	else if (key == '3')
	{
		currentWindow = 2; mode = 'z';
	}
	else if (key == '1')
	{
		currentWindow = 0; mode = 'z';
	}
}

/////////////////////////process mouse control///////////////////////////////// - Shi
void processMouseButtons(int button, int state, int x, int y)
{
	if (mode == 'z')
	{
		if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
		{
			if (x < winWidth/2 && y < winHeight/2)
			{
				mode = 'q';
			}
			else if (x < winWidth/2 && y > winHeight/2)
			{
				mode = 'a';
			}
			else if (x > winWidth/2 && y < winHeight/2)
			{
				mode = 'w';
			}
			else if (x > winWidth/2 && y > winHeight/2)
			{
				mode = 's';
			}
		}
	}
	else // the other 4 modes
	{
		if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
		{
			mode = 'z';
		}
	}
}

/////////////////////////process mouse motion////////////////////////////////// - Shi

void PassiveMouseMotion(int x, int y)
{
    if (x<0)
        mouseWindowX = -1;
    else if (x>winWidth)
        mouseWindowX = 1;
    else
        mouseWindowX = 2* (x / (float) winWidth) - 1.0;
           
    if (y<0)
        mouseWindowY = -1;
    else if (y>winHeight)
        mouseWindowY = 1;
    else
        mouseWindowY = 2* (y / (float) winHeight) - 1.0;
}

//////////////////////////////////////////////////////////////////////////////// just added some spaces - Shi

GLuint setShaders(char * vert, char * frag) {
    GLuint v,f, pro;
	char *vs,*fs;

	v = glCreateShader(GL_VERTEX_SHADER);
	f = glCreateShader(GL_FRAGMENT_SHADER);

	vs = textFileRead(vert);
	fs = textFileRead(frag);

	const char * vv = vs;
	const char * ff = fs;

	glShaderSource(v, 1, &vv, NULL);
	glShaderSource(f, 1, &ff, NULL);

	free(vs);
	free(fs);

	glCompileShader(v);
	glCompileShader(f);

	printShaderLog(v);
	printShaderLog(f);

	pro = glCreateProgram();
	glAttachShader(pro,v);
	glAttachShader(pro,f);

	glLinkProgram(pro);
	printProgramLog(pro);
	
	return(pro);
}

////////////////////////////////////////////////////////////////////////////////

int main(int argc, char **argv) {

	// initialize camera or reading from video file
	capture = cvCaptureFromCAM(0);
	//capture = cvCaptureFromFile("test.m4v");  // could also capture from a file

	if(!capture) 
	{
		printf("Cannot get access to the video feed (from file or camera)!\n");
		return 1;
	}
	
	make3DNoiseTexture();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(250,200); //changed parameters to change the position of the window - Shi
	glutInitWindowSize(winWidth, winHeight);

	glutCreateWindow("GPU Programming-P1 - Yin | Window 1");

	glutDisplayFunc(renderScene);
	glutIdleFunc(renderScene);
	glutReshapeFunc(changeSize);
	glutKeyboardFunc(processNormalKeys);
	
	// added mouse control functionality - Shi
	glutMouseFunc(processMouseButtons);
	glutPassiveMotionFunc(PassiveMouseMotion);

	glewInit();
	
	glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_RECTANGLE_ARB);

	glClearColor(0.0,0.0,0.0,1.0);
 

	if (GLEW_ARB_vertex_shader && GLEW_ARB_fragment_shader)
		printf("Ready for GLSL\n");
	else {
		printf("No GLSL support\n");
		exit(1);
	}

	p = setShaders((char *) "./webcam.vert", (char *) "./webcam.frag");
	
	glGenTextures(1, &cameraImageTextureID);
	glActiveTexture(GL_TEXTURE0 + 0); //GL_TEXTURE0
	
	glGenTextures(1, &noise3DTexName);
	glActiveTexture(GL_TEXTURE0 + 1);
	
	glBindTexture(GL_TEXTURE_3D, noise3DTexName);
	
	glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	
	glTexImage3D(GL_TEXTURE_3D, 0, GL_RGBA,
				 noise3DTexSize, noise3DTexSize, noise3DTexSize, 
				 0, GL_RGBA, GL_UNSIGNED_BYTE, noise3DTexPtr);
	
	glutMainLoop();
	return 0;
}
