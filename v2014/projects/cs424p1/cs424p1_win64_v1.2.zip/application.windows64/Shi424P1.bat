@echo off
java -Djava.ext.dirs=lib -Djava.library.path=lib Shi424P1
