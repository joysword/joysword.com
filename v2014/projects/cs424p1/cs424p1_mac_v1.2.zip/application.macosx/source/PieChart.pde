class PieChart
{
  
  int[] colors;
  float[] percentages;
  float total;
  PVector center;
  float radius;
  
  boolean isDisplay;
  
  int index;

  String stats;
  
  PieChart(float[] theData, int n, int[] _colors, float x, float y, float _radius, int i)
  {

    updateData(theData, n, _colors, i);
    center = new PVector(x, y);
    radius = _radius;
    
    isDisplay = false;
  }

  public void updateData(float[] theData, int n, int[] _color, int index)
  {
    percentages = new float[n];
    float count = 0;

    // loop through data
    for (int i = 0; i < n; i++)
    {
      float theValue = theData[i];
      if (theValue >=0 ) count += theValue;
      if (theValue >=0 ) {
        percentages[i] = theValue;
      } else {percentages[i] = 0;
      }
    }
    
    if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
     if(index != 4 && index != 2) {
      total = percentages[1];
      percentages[1] = percentages[1] - percentages[0];
      stats = nf(percentages[0]/total*100,0,2) + "%";    
     } else {
      total = count;
      stats = nf(percentages[0]/percentages[1]*100,0,2) + "%";
     }
    }
    else // MULTI_COUNTRY_MODE
    {
      total = count;
    }
    colors = _color;
  }

  public void render()
  {
    if (isDisplay) {
      
      float startDegree = 0.0;

      pushStyle();
      stroke(#818181);
      strokeWeight(2*scale);
      
        for (int i = 0; i < percentages.length; i++)
        {
          if (percentages[i] > 0)
          {
            fill (colors[i]);
            float len = map(percentages[i], 0, total, 0.0, TWO_PI); 
            arc(center.x, center.y, radius, radius, startDegree, startDegree + len);
            startDegree += len;
          }
        }

        if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
          textAlign(RIGHT,CENTER);
          fill(0);
          textSize(15*scale);
          text(stats, Width-15*scale, center.y);
        }// end of ONE_COUNTRY_MODE
        else { // MULTI_COUNTRY_MODE
          fill(0);
          
          textSize(10*scale);
          int ct = 0;
          for (int i=0;i<DATA_SET_COUNT;i++) {
            if (currentDisplay[i] == true) {
              textAlign(LEFT, CENTER);
              text(countryNames[currentRow[i]], Width - 210*scale, 130*scale + ct*30*scale);
              textAlign(RIGHT, CENTER);
              text(nf(percentages[ct]/total*100, 0, 2) + "%", Width - 5*scale, 130*scale + ct*30*scale);
              ct++;
            }
          }
        }
      popStyle();
    }
  }

  public void setCenter(float x, float y)
  {
    center.x = x; 
    center.y = y;
  }

  public void setRadius(float r) {
    radius = r;
  }
  
  public void test() {
    println("test");
  }
  
  public boolean getIsDisplay() {
    return isDisplay;
  }
  public void setNotDisplay() {
    isDisplay = false;
  }
  
  public void setDisplay() {
    isDisplay = true;
  }
  
  public void setIfDisplay(boolean ss) {
    isDisplay = ss;
  }
}
