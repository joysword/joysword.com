class UserInterface
{
  CheckItem[] dataSelector; //6 
  CheckItem[] countrySelector; //2
  CheckItem[] totalSelector; //2
  CheckItem[] yearSelector;
  PieButton pieButton;

  //Range range;

  CountryList countryList;

  TimeLine timeLine;

  HelpWindow helpWindow;

  MapWindow mapWindow;

  SearchWindow searchWindow;
  
  TableWindow tableWindow;
  
  EventWindow event;

  private int displayMode; //ONE_COUNTRY_MODE; MULTI_COUNTRY_MODE;

  private int yearMode;

  private int pieChartMode; //REGION_MODE; WORLD_MODE;

  private int countryCount;

  private int dataSetCount;
  

  //
  //
  //
  // iiiiiiinitiateeeeeeeeeeeee
  //
  //
  /////////////////
  ///////////
  /////////////////////
  ////////////////////////////
  UserInterface() { 

    //List Box 1
    //myList = setupListBox("Countries", "SELECT COUNTRY");
    //myList = setupListBox("Countries2", "SELECT COUNTRY 2");


    // initiate selectors
    countrySelector = new CheckItem[2];
    countrySelector[0] = new CheckItem(COUNTRY_SELECTOR_X, COUNTRY_SELECTOR_Y, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "ONE-COUNTRY Mode");
    countrySelector[1] = new CheckItem(COUNTRY_SELECTOR_X, COUNTRY_SELECTOR_Y+CHECK_ITEM_HEIGHT+3*scale, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "MUTLI-COUNTRY Mode");

    countrySelector[0].setActive();

    dataSelector = new CheckItem[DATA_SET_COUNT];
    dataSelector[0] = new CheckItem(DATA_SELECTOR_X, DATA_SELECTOR_Y, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "Energy Production");
    dataSelector[1] = new CheckItem(DATA_SELECTOR_X, DATA_SELECTOR_Y_2, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "Energy Consumption");
    dataSelector[2] = new CheckItem(DATA_SELECTOR_X, DATA_SELECTOR_Y_3, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "Energy Consumption Per");
    dataSelector[3] = new CheckItem(DATA_SELECTOR_X+DATA_SELECTOR_DIFF, DATA_SELECTOR_Y, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "CO2 Emission");
    dataSelector[4] = new CheckItem(DATA_SELECTOR_X+DATA_SELECTOR_DIFF, DATA_SELECTOR_Y_2, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "CO2 Emission Per");
    dataSelector[5] = new CheckItem(DATA_SELECTOR_X+DATA_SELECTOR_DIFF, DATA_SELECTOR_Y_3, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "Renewable Electricity Gen");
    dataSelector[6] = new CheckItem(DATA_SELECTOR_X+DATA_SELECTOR_DIFF*2, DATA_SELECTOR_Y_3, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "Population!");

    dataSelector[0].setActive();

    totalSelector = new CheckItem[2];
    totalSelector[0] = new CheckItem(TOTAL_SELECTOR_X, TOTAL_SELECTOR_Y, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, " % in Region");
    totalSelector[1] = new CheckItem(TOTAL_SELECTOR_X, TOTAL_SELECTOR_Y+TOTAL_DIFF, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, " % in World");

    totalSelector[0].setActive();

    yearSelector = new CheckItem[2];
    yearSelector[0] = new CheckItem(YEAR_SELECTOR_X, YEAR_SELECTOR_Y, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "show data by Year");
    yearSelector[1] = new CheckItem(YEAR_SELECTOR_X+YEAR_DIFF, YEAR_SELECTOR_Y, CHECK_BOX_WIDTH, BUTTON_WIDTH, CHECK_ITEM_HEIGHT, "show data by Decade");

    yearSelector[0].setActive();

    timeLine = new TimeLine(plotX1, plotY2 + 40*scale, plotX2-plotX1, 5*scale, TIME_LOCK_W, TIME_LOCK_H);

    pieButton = new PieButton(PIE_BUTTON_X, PIE_BUTTON_Y, PIE_BUTTON_H, PIE_BUTTON_DIFF);

    displayMode = ONE_COUNTRY_MODE;
    pieChartMode = REGION_MODE;

    yearMode = YEAR_MODE;

    countryCount = 1;
    dataSetCount = 1;

    countryList = new CountryList(LIST_X, LIST_Y, LIST_W, LIST_LINE_H, PAGE_BTN_X, PAGE_BTN_Y, PAGE_BTN_W, PAGE_BTN_DIFF);

    mapWindow = new MapWindow(MAP_WINDOW_X, MAP_WINDOW_Y, MAP_WINDOW_WIDTH, MAP_WINDOW_CAPTION, M_CAPTION_HEIGHT, M_WINDOW_HEIGHT, MAP_BUTTON_X, MAP_BUTTON_Y, MAP_BUTTON_LEN);

    searchWindow = new SearchWindow(SEARCH_WINDOW_X, SEARCH_WINDOW_Y, SEARCH_WINDOW_WIDTH, SEARCH_WINDOW_CAPTION, S_CAPTION_HEIGHT, S_WINDOW_HEIGHT, SEARCH_BUTTON_X, SEARCH_BUTTON_Y, SEARCH_BUTTON_LEN);

    helpWindow = new HelpWindow(HELP_WINDOW_X1, HELP_WINDOW_Y1, (HELP_WINDOW_X2-HELP_WINDOW_X1), (HELP_WINDOW_Y2-HELP_WINDOW_Y1), HelpContent, HELP_BUTTON_X, HELP_BUTTON_Y, HELP_BUTTON_LEN);
    
    tableWindow = new TableWindow(TABLE_WINDOW_X, TABLE_WINDOW_Y, TABLE_W, TABLE_H, TABLE_BTN_X, TABLE_BTN_Y, TABLE_BTN_LEN, TABLE_PAGE_BTN_X,TABLE_PAGE_BTN_Y,TABLE_PAGE_BTN_H,TABLE_PAGE_BTN_DIFF);
    
    event = new EventWindow(EVENT_BTN_X, EVENT_BTN_Y, EVENT_BTN_LEN);
  } 
  //end of constructor
  //end of constructor
  //end of constructor
  //end of constructor
  //end of constructor

  public void render()
  {
    // render country list

    // render check items
    for (int i=0;i<2;i++)
    {
      countrySelector[i].render();
      totalSelector[i].render();
      yearSelector[i].render();
    }
    for (int i=0;i<DATA_SET_COUNT;i++)
    {
      dataSelector[i].render();
    }

    // render country list
    countryList.render();

    // render time line
    timeLine.render();

    // render pie buttons
    pieButton.render();

    // render events
    event.render();
    
    // render table
    tableWindow.render();
    // render world map
    mapWindow.render();
    // 2nd last step is to render keyboard
    searchWindow.render();
    // last step is to render help window
    helpWindow.render();
  }

  public int getDisplayMode()
  {
    return displayMode;
  }

  public int getYearMode()
  {
    return yearMode;
  }

  public int getPieChartMode()
  {
    return pieChartMode;
  }

  public void setDisplayMode(int dismode)
  {
    displayMode = dismode;
  }

  public void setYearMode(int dismode)
  {
    yearMode = dismode;
  }

  public void setPieChartMode(int dismode)
  {
    pieChartMode = dismode;
  }

  public void updateCountryList(float posx, float posy) {
    countryList.update(posx, posy);
    updateDataForPieChart();
  }

  public void updateYearSelector(float posx, float posy) {
    if (posx >= yearSelector[0].getX() && posx <= yearSelector[0].getX() + yearSelector[0].getCBW()
      && posy >= yearSelector[0].getY() && posy <= yearSelector[0].getY() + yearSelector[0].getH()) {
      yearSelector[0].setCheck(true);
      yearSelector[1].setCheck(false);

      yearMode = YEAR_MODE;
      updateDataForPieChart();
    }
    if (posx >= yearSelector[1].getX() && posx <= yearSelector[1].getX() + yearSelector[1].getCBW()
      && posy >= yearSelector[1].getY() && posy <= yearSelector[1].getY() + yearSelector[1].getH()) {
      yearSelector[1].setCheck(true);
      yearSelector[0].setCheck(false);

      yearMode = DECADE_MODE;
      println(yearMode);
      timeLine.resume();
      updateDataForPieChart();
    }
  }

  public void updateCountrySelector(float posx, float posy) {
    if ( posx >= countrySelector[0].getX() && posx<= countrySelector[0].getX()+countrySelector[0].getCBW()
      && posy >= countrySelector[0].getY() && posy <= countrySelector[0].getY()+countrySelector[0].getH()) {
      countrySelector[0].setCheck(true);
      countrySelector[1].setCheck(false);

      displayMode = ONE_COUNTRY_MODE;
      for (int i=0;i<DATA_SET_COUNT;i++)
      {
        pieChart[i].setIfDisplay(dataSelector[i].getCheck());
      }
      updateLegend();
      updateDataForPieChart();
    }
    if ( posx >= countrySelector[1].getX() && posx<= countrySelector[1].getX()+countrySelector[1].getCBW()
      && posy >= countrySelector[1].getY() && posy <= countrySelector[1].getY()+countrySelector[1].getH()) {
      countrySelector[1].setCheck(true);
      countrySelector[0].setCheck(false);

      displayMode = MULTI_COUNTRY_MODE;
      //currentDisplay[0] = true;
      //pieChart[0].setDisplay();
      //for (int i=1;i<6;i++) {
        //currentDisplay[i] = false;
        //pieChart[i].setNotDisplay();
      //}

      // only one data set will be displayed in MULTI_COUNTRY_MODE
      boolean find = false;
      for (int i=0;i<DATA_SET_COUNT;i++) {
        if (!find && dataSelector[i].getCheck()) {
          find = true;
          continue;
        }
        if (find) {
          dataSelector[i].setNotActive();
        }
      }

      updateLegend();
      updateDataForPieChart();
    }
  }

  public void updateDataSelector(float posx, float posy) {
    int id = -1;
    for (int i=0;i<DATA_SET_COUNT;i++) {
      if ( posx >= dataSelector[i].getX() && posx<= dataSelector[i].getX() + dataSelector[i].getCBW()
        && posy >= dataSelector[i].getY() && posy <= dataSelector[i].getY() + dataSelector[i].getH()) {
        if (dataSelector[i].getCheck()) {
          dataSelector[i].setNotActive();
          pieChart[i].setNotDisplay();
        } 
        else {
          dataSelector[i].setActive();
          pieChart[i].setDisplay();
          id = i;
          println("data " + i + " is active");
        }
        //println("dataSelector["+i+"] is now" + (dataSelector[i].getCheck()?"active":"not active"));
        //id = i;
        break;
      }
    }
    if (id > -1 && displayMode == MULTI_COUNTRY_MODE) {
      for (int i=0;i<DATA_SET_COUNT;i++) {
        if (i != id) {
          dataSelector[i].setCheck(false);
        }
      }
      for (int i=1;i<DATA_SET_COUNT;i++) {
        pieChart[i].setNotDisplay();
      }
      pieChart[0].setDisplay();
      dataScale = 1;
    }
  }

  public void updateTotalSelector(float posx, float posy) {
    if ( posx >= totalSelector[0].getX() && posx<= totalSelector[0].getX()+totalSelector[0].getCBW()
      && posy >= totalSelector[0].getY() && posy <= totalSelector[0].getY()+totalSelector[0].getH()) {
      totalSelector[0].setCheck(true);
      totalSelector[1].setCheck(false);

      pieChartMode = REGION_MODE;
      updateDataForPieChart();
    }
    if ( posx >= totalSelector[1].getX() && posx<= totalSelector[1].getX() + totalSelector[1].getCBW()
      && posy >= totalSelector[1].getY() && posy <= totalSelector[1].getY()+totalSelector[1].getH()) {
      totalSelector[1].setCheck(true);
      totalSelector[0].setCheck(false);

      pieChartMode = WORLD_MODE;
      updateDataForPieChart();
    }
  }

  public void updateMapWindow(float posx, float posy) {
    mapWindow.update(posx, posy);
  }

  public void updateSearchWindow(float posx, float posy) {
    searchWindow.update(posx, posy);
  }

  public void updateHelpWindow(float posx, float posy) {
    helpWindow.update(posx, posy);
  }

  public void updateCountryDisplay(float posx, float posy) {
    countryList.updateCountryDisplay(posx, posy);
    updateDataForPieChart();
  }


  public MapWindow getMapWindow() {
    return mapWindow;
  }

  public SearchWindow getSearchWindow() {
    return searchWindow;
  }

  public HelpWindow getHelpWindow() {
    return helpWindow;
  }

  public CountryList getCountryList() {
    return countryList;
  }

  private void updateLegend() {
    for (int i=0;i<DATA_SET_COUNT;i++) {
      legend[i].update(i);
    }
  }

  public PieButton getPieButton() {
    return pieButton;
  }

  private void updateDataForPieChart() {

    if (displayMode == ONE_COUNTRY_MODE) {
      for (int i=0;i<DATA_SET_COUNT;i++) {
        float[] dataa = new float[2];
        dataa[0] = dataSets[i].getData().getFloat(currentRow[0], getPieButton().getYear()-yearMin);
        dataa[1] = dataSets[i].getData().getFloat(getRegion(currentRow[0]), getPieButton().getYear()-yearMin);
        //println(i+": " + dataa[0]+ "  " +dataa[1]);
        pieChart[i].updateData(dataa, 2, defaultColor[i], i);
        //println("update " + i + ": " + dataa[0] + " " + dataa[1] + ", from " + countryNames[currentRow[0]] + " of " + countryNames[getRegion(currentRow[0])]);
      }
    }
    if (displayMode == MULTI_COUNTRY_MODE) {
      float data[] = new float[DATA_SET_COUNT];
      int colour[] = new color[DATA_SET_COUNT];
      int whichData = 0;
      while (whichData<DATA_SET_COUNT && dataSelector[whichData].getCheck () == false) whichData++;
      if (whichData >=DATA_SET_COUNT) {
      }
      else {
        println("data: " + whichData);
        int cnt = 0;
        for (int j=0;j<DATA_SET_COUNT;j++) {
          if (currentDisplay[j] == true) {
            data[cnt] = dataSets[whichData].getData().getFloat(currentRow[j], getPieButton().getYear()-yearMin);
            colour[cnt] = colors[j]; 
            cnt++;
          }
        }
        println("cnt: " +cnt);
        pieChart[0].updateData(data, cnt, colour, 0);
        pieChart[0].setDisplay();
        //pieChart[0].updateData(data, colour);
      }
    } // end of multi mode
  } // end of updateDataForPieChart()

  public void updateTimeLineL(float posx) {
    timeLine.update(posx, 0);
  }
  public void updateTimeLineR(float posx) {
    timeLine.update(posx, 1);
  }
  public void updatePieButton(float posx, float posy) {
    pieButton.update(posx, posy);
    updateDataForPieChart();
  }

  public TimeLine getTimeLine() {
    return timeLine;
  }

  public CheckItem getDataSelector(int num) {
    return dataSelector[num];
  }
  
  public void updateDataMax(float currentY) {
    dataScale = dataScale * (plotY2 - dragStartY) / (plotY2 - currentY);
    println("dataScale: " + dataScale);
  }
  
  public boolean getShowTable() {
    return tableWindow.getIsDisplay();
  }
  
  public TableWindow getTable() {
    return tableWindow;
  }
  
  public void updateTable(float posx, float posy) {
    tableWindow.updateButton(posx, posy);
    tableWindow.updatePage(posx, posy);
  }
  
  public TableWindow getTableWindow() {
    return tableWindow;
  }
  
  public void updateEvent(float posx, float posy) {
    event.update(posx, posy);
  }
}

