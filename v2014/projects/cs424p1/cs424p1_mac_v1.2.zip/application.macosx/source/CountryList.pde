class CountryList {
  
  float x,y;
  float lineH;
  float w;
  
  String[] item;
  
  int cnt;
  int totalCnt;
  
  int page;
  int pageCount;
  
  float btn_x;
  float btn_y;
  float btn_w;
  float btn_diff;
  
  CountryList(float _x, float _y, float _w, float _h, float bx, float by, float bw, float diff) {
    x = _x;
    y = _y;
    w = _w;
    lineH = _h;
    btn_x = bx;
    btn_y = by;
    btn_w = bw;
    btn_diff = diff;
    
    totalCnt = dataSets[0].getData().getRowCount();
    item = new String[totalCnt];
    
    for (int i=0; i<totalCnt; i++) {
      if (i == 0 || i == 7 || i == 53 || i == 95 || i == 112 || i == 127 || i == 184) {
        item[i] = dataSets[0].getData().getRowName(i).toUpperCase();
      }
      else
      {
        item[i] = "  " + dataSets[0].getData().getRowName(i);
      }
    }
    
    cnt = totalCnt;
    page = 0;
    pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
  }
  
  public void updateBySearch(String strrr) {
    cnt = 0;
    for (int i=0;i<totalCnt;i++) {
      
      /* if can search a region
      String name = dataSets[0].getData().getRowName(i);
      if (strrr.equalsIgnoreCase(name.substring(0,strrr.length())) == true)
      {
        if (i == 0 || i == 7 || i == 53 || i == 95 || i == 112 || i == 127 || i == 184 || i == totalCnt-1) {
          item[cnt] = name.toUpperCase();
        } else {
          item[cnt] = "  " + name;
        }
        cnt++;
      }
      */
      
      if (i == 0 || i == 7 || i == 53 || i == 95 || i == 112 || i == 127 || i == 184) { continue; }
      if (strrr.length() <= countryNames[i].length())
      {
        if (strrr.equalsIgnoreCase(countryNames[i].substring(0,strrr.length())) == true)
        {
          item[cnt] = "  " + countryNames[i];
          cnt++;
        }
      }
      println("count:"+cnt);
      page = 0;
      pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
    }
  }
  
  public void updateByMap(int region) {
    switch (region)
    {
      case N_AME:
        item[0] = countryNames[0].toUpperCase();
        cnt = 1;
        for (int i=1;i<7;i++) {
          item[cnt] =  "  " + countryNames[i];
          cnt ++;
        }
        page = 0;
        pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
        break;
      case S_AME:
        item[0] = countryNames[7].toUpperCase();
        cnt = 1;
        for (int i=8;i<53;i++) {
          item[cnt] =  "  " + countryNames[i];
          cnt ++;
        }
        page = 0;
        pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
        break;
      case AFRI:
        item[0] = countryNames[127].toUpperCase();
        cnt = 1;
        for (int i=128;i<184;i++) {
          item[cnt] =  "  " + countryNames[i];
          cnt ++;
        }
        page = 0;
        pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
        break;
      case EURO:
        item[0] = countryNames[53].toUpperCase();
        cnt = 1;
        for (int i=54;i<95;i++) {
          item[cnt] =  "  " + countryNames[i];
          cnt ++;
        }
        page = 0;
        pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
        break;
      case RUS:
        item[0] = countryNames[95].toUpperCase();
        cnt = 1;
        for (int i=96;i<112;i++) {
          item[cnt] =  "  " + countryNames[i];
          cnt ++;
        }
        page = 0;
        pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
        break;
      case ASIA:
        item[0] = countryNames[184].toUpperCase();
        cnt = 1;
        for (int i=185;i<231;i++) {
          item[cnt] =  "  " + countryNames[i];
          cnt ++;
        }
        page = 0;
        pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
        break;
      case MID:
        item[0] = countryNames[112].toUpperCase();
        cnt = 1;
        for (int i=113;i<127;i++) {
          item[cnt] =  "  " + countryNames[i];
          cnt ++;
        }
        page = 0;
        pageCount = (cnt % HOW_MANY_LINES_IN_A_PAGE == 0)? (cnt / HOW_MANY_LINES_IN_A_PAGE):(cnt/HOW_MANY_LINES_IN_A_PAGE + 1);
        break;
      case -11: break;
    }
  }
  
  public void render() {
    pushStyle();
    fill(245);
    stroke(0);
    strokeWeight(scale);
    rectMode(CORNER);
    rect(x,y,w,lineH*HOW_MANY_LINES_IN_A_PAGE);
    fill(224);
    noStroke();
    for (int i=1;i<HOW_MANY_LINES_IN_A_PAGE;i++) {
      //line(x,y+lineH*i,x+w,y+lineH*i);
      if (i%2==1) {
        rect(x+scale,y+lineH*(i-1)+scale,w-scale,lineH);
      }
    }
    popStyle();
    renderButton();
    renderName();
  }
  
  private void renderName() {
    pushStyle();
    int begin = page*HOW_MANY_LINES_IN_A_PAGE;
    int end;
   
    if (begin+HOW_MANY_LINES_IN_A_PAGE < cnt) {
      end = begin+HOW_MANY_LINES_IN_A_PAGE;
    } else {
      end = cnt;
    }
    fill(0);
    textAlign(LEFT, CENTER);
    for (int i=begin;i<end;i++) {
      text(item[i], x+2*scale, y+(i-begin)*lineH+lineH*0.5);
    }
    popStyle();
  }
  
  private void renderButton() {
    pushStyle();
    fill(127);
    noStroke();
    triangle(btn_x, btn_y, btn_x+btn_w, btn_y, btn_x + btn_w*0.5, btn_y - btn_w * 0.5);
    triangle(btn_x, btn_y+btn_diff, btn_x+btn_w, btn_y+btn_diff, btn_x + btn_w*0.5, btn_y + btn_w * 0.5 + btn_diff);
    popStyle();
  }
  
  public void update(float _x, float _y) {
    if (ui.searchWindow.getIsDisplay() == false && ui.mapWindow.getIsDisplay() == false) {
      if (_x>= btn_x && _x <= btn_x + btn_w && _y >= btn_y - btn_w * 0.5 && _y <= btn_y) {
        if (page > 0) {
          page--;
        }
      } else if (_x>= btn_x && _x <= btn_x + btn_w && _y >= btn_y +btn_diff * 0.5 && _y <= btn_y + btn_diff + btn_w * 0.5) {
        if (page<pageCount-1) {
          page++;
        }
      }
    }
  }
  
  public void updateCountryDisplay(float _x, float _y) {
    if (ui.searchWindow.getIsDisplay() == false && ui.mapWindow.getIsDisplay() == false) {
      if (_x >= x && _x <= x+w) {
        for (int i=0;i<HOW_MANY_LINES_IN_A_PAGE;i++) {
          if (_y>= y + lineH*i && _y < y + lineH*(i+1)) {
            String select = item[page*HOW_MANY_LINES_IN_A_PAGE + i];
            if (select.substring(0, 2).equals("  ") == true) {
              select = select.substring(2);
            }
            for (int j=0;j<totalCnt; j++) {
              if (select.equalsIgnoreCase(countryNames[j]) == true) {
                if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
                  currentRow[0] = j;
                } else if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
                  //println("MULTI_COUNTRY_MODE");
                  int ii=0;
                  while (ii<DATA_SET_COUNT && currentDisplay[ii] == true) ii++;
                  if (ii >= DATA_SET_COUNT) {
                    //println("don't have place to display new country");
                    break;
                  }
                  // if ii < 6
                  currentDisplay[ii] = true;
                  currentRow[ii] = j;
                  legend[ii].updateString(countryNames[j]);
                  
                  //test
                  for (int k = 0;k<DATA_SET_COUNT;k++) {
                    println(currentDisplay[k] + "    " + countryNames[currentRow[k]]);
                  }
                  //end of test
                }
              }
            }
            break;
          }
        }
      }
    }
  }
}
    
