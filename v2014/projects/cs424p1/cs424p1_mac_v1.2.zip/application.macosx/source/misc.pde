final int DATA_SET_COUNT = 7;


//about data sets
DataSets[] dataSets;
int rowCount;
int columnCount;
int[] years;
String[] countryNames;

//about PLOT and TABLE
float plotX1, plotY1;
float plotX2, plotY2;
float labelX, labelY;
float tableY1, tableY2;
int yearMin, yearMax;
int showYearMin, showYearMax;

int yearCount;
float unitWidth;
float unitHeight;

int displayNumber; // how many data sets are being displayed

//regions of the world
final int N_AME = 1;
final int S_AME = 2014;
final int AFRI = 2010;
final int EURO = 2012;
final int RUS = 1991;
final int ASIA = 1024;
final int MID = 10000000;

//about PIE CHART
final int DEFAULT_PIE_COLOR = 245;
final float PIE_CHART_X = Width - 130*scale;
final float PIE_CHART_Y = 80*scale;
final float PIE_CHART_R = 50*scale; // Diameter, not Radius
final float PIE_CHART_DIS = 55*scale;

PieChart[] pieChart;

int[][] defaultColor;

//about DASHLINE
final float DASH_LINE_SPACING1 = 3.0*scale;
final float DASH_LINE_SPACING2 = 5.0*scale;

//about visualization
PFont plotFont;
int[] colors; 

//about display modes
final int ONE_COUNTRY_MODE = 0;
final int MULTI_COUNTRY_MODE = 1;

//about year or decade mode
final int YEAR_MODE = 0;
final int DECADE_MODE = 1;

final int REGION_MODE = 0;
final int WORLD_MODE = 1;

//about coutrt list
final float LIST_X = 70*scale;
final float LIST_Y = 110*scale;
final float LIST_W = 180*scale;
final float LIST_LINE_H = 20*scale;
final int HOW_MANY_LINES_IN_A_PAGE = 12;
final float PAGE_BTN_DIFF = 10*scale;
final float PAGE_BTN_Y = LIST_Y + HOW_MANY_LINES_IN_A_PAGE * LIST_LINE_H * 0.5 - PAGE_BTN_DIFF * 0.5; // make the button in the CENTER of the list
final float PAGE_BTN_X = LIST_X + LIST_W + 8*scale;
final float PAGE_BTN_W = 26*scale;

final float LEGEND_DIFF = 10*scale;

//about selectors
final float CHECK_BOX_WIDTH = 12*scale;
final float BUTTON_WIDTH = 100*scale;
final float CHECK_ITEM_HEIGHT = 12*scale;

final float COUNTRY_SELECTOR_X = 5*scale;
final float COUNTRY_SELECTOR_Y = Height-80*scale;

final float DATA_SELECTOR_X = 150*scale;
final float DATA_SELECTOR_Y = COUNTRY_SELECTOR_Y;
final float DATA_SELECTOR_Y_2 = DATA_SELECTOR_Y + CHECK_ITEM_HEIGHT + 3*scale;
final float DATA_SELECTOR_Y_3 = DATA_SELECTOR_Y_2 + CHECK_ITEM_HEIGHT + 3*scale;
final float DATA_SELECTOR_Y_4 = DATA_SELECTOR_Y_3 + CHECK_ITEM_HEIGHT + 3*scale;
final float DATA_SELECTOR_DIFF = 150*scale;

final float TOTAL_SELECTOR_X = Width-380*scale;
final float TOTAL_SELECTOR_Y = Height-50*scale;
//final float TOTAL_DIFF = 100*scale; //for different X
final float TOTAL_DIFF = CHECK_ITEM_HEIGHT+3*scale; //for different Y

float YEAR_SELECTOR_X;
final float YEAR_SELECTOR_Y = TOTAL_SELECTOR_Y;
final float YEAR_DIFF = 150*scale;

//about pie button
final float PIE_BUTTON_X = TOTAL_SELECTOR_X+120*scale;
final float PIE_BUTTON_Y = TOTAL_SELECTOR_Y;
final float PIE_BUTTON_H = PAGE_BTN_W;
final float PIE_BUTTON_DIFF = PAGE_BTN_DIFF;

//about windows and window buttons
final float SEARCH_WINDOW_X = 100*scale;
final float SEARCH_WINDOW_Y = 140*scale;
final float SEARCH_WINDOW_WIDTH = 500*scale;
final String SEARCH_WINDOW_CAPTION = "SEARCH A COUNTRY";
final float S_CAPTION_HEIGHT = 40*scale;
final float S_WINDOW_HEIGHT = 180*scale;

final float SEARCH_BUTTON_X = 0*scale;
final float SEARCH_BUTTON_Y = 150*scale;
final float SEARCH_BUTTON_LEN = 50*scale;

final float MAP_WINDOW_X = 100*scale;
final float MAP_WINDOW_Y = 100*scale;
final float MAP_WINDOW_WIDTH = 500*scale;
final String MAP_WINDOW_CAPTION = "SELECT A REGION";
final float M_CAPTION_HEIGHT = S_CAPTION_HEIGHT;
final float M_WINDOW_HEIGHT = MAP_WINDOW_WIDTH * (2234.0/4500.0);

final float MAP_BUTTON_X = SEARCH_BUTTON_X;
final float MAP_BUTTON_Y = SEARCH_BUTTON_Y + 70*scale;
final float MAP_BUTTON_LEN = SEARCH_BUTTON_LEN;

final float HELP_WINDOW_X1 = 550*scale;
final float HELP_WINDOW_X2 = 1000*scale;
final float HELP_WINDOW_Y1 = 70*scale;
final float HELP_WINDOW_Y2 = Height-150*scale;

final float HELP_BUTTON_X = SEARCH_BUTTON_X;
final float HELP_BUTTON_Y = SEARCH_BUTTON_Y + 140*scale;
final float HELP_BUTTON_LEN = SEARCH_BUTTON_LEN;

//about time line
final float TIME_LOCK_W = 5*scale;
final float TIME_LOCK_H = 5*scale;

//about keys on keyboard
final int ZHONG = 1024;
final int WRONG = 5858; 

final int BOTTOM_HEIGHT = 0;

//about tabular form
final float TABLE_BTN_X = 20*scale;
final float TABLE_BTN_Y = Height - 50*scale;
final float TABLE_BTN_LEN = 50*scale;

float TABLE_WINDOW_X;
final float TABLE_WINDOW_Y = 10*scale;
final float TABLE_W = 72*scale;
final float TABLE_H = 43*scale;

float TABLE_PAGE_BTN_X;
final float TABLE_PAGE_BTN_Y = TABLE_WINDOW_Y + TABLE_H * 3.5;
final float TABLE_PAGE_BTN_H = PIE_BUTTON_H;
final float TABLE_PAGE_BTN_DIFF = PIE_BUTTON_DIFF;

//about event button
final float EVENT_BTN_X = TABLE_BTN_X + TABLE_BTN_LEN + 5*scale;
final float EVENT_BTN_Y = TABLE_BTN_Y;
final float EVENT_BTN_LEN = TABLE_BTN_LEN;



// colors
int COLOR_0 = #ff0000;
int COLOR_1 = #ff6600;
int COLOR_2 = #FFC61E;
int COLOR_3 = #00611c;
int COLOR_4 = #01b2f1;
int COLOR_5 = #0000ff;
int COLOR_6 = #BB16F7;

String HelpContent = "Electric Avenue\nShi Yin\nComputer Science Department\nUniversity of Illinois at Chicago\n\n====\nmore information and how to use:\nhttp://joysword.com/projects/cs424p1/index.html";

boolean isNansilafu(int i) {
  if (i == 67 || i == 79 || i == 89 || i == 97 || i == 59 || i == 66 || i == 92 || i == 86) {
    return true;
  }
  return false;
}
boolean isCzechSlovakia(int i) {
  if (i == 61 || i == 65 || i == 88) {
    return true;
  }
  return false;
}
boolean isGermany(int i) {
  if (i >= 69 && i <= 71) return true;
  return false;
}
boolean isUSSR(int i) {
  if (i >= 96 && i <= 111) return true;
  return false;
}
