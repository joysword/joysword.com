void touchDown(int ID, float xPos, float yPos, float xWidth, float yWidth) {
  if (ui.getTableWindow().getIsDisplay() == false) {
    if (xPos >= ui.getTimeLine().getLeftLock().getX()-TIME_LOCK_W-8*scale && xPos <= ui.getTimeLine().getLeftLock().getX()+TIME_LOCK_W+8*scale
      && yPos >= ui.getTimeLine().getLeftLock().getY()-TIME_LOCK_H-8*scale && yPos <= ui.getTimeLine().getLeftLock().getY()+TIME_LOCK_H+8*scale)
    {
      isDragLeft = true;
      //println(isDragLeft);
    } 
    else if (xPos >= ui.getTimeLine().getRightLock().getX()-TIME_LOCK_W-8*scale && xPos <= ui.getTimeLine().getRightLock().getX()+TIME_LOCK_W+8*scale
      && yPos >= ui.getTimeLine().getRightLock().getY()-TIME_LOCK_H-8*scale && yPos <= ui.getTimeLine().getRightLock().getY()+TIME_LOCK_H+8*scale)
    {
      isDragRight = true;
      //println(isDragRight);
    }
    if (xPos > plotX1 && xPos < plotX2 && yPos > plotY1 && yPos < plotY2) {
      isDrag = true;
      dragStartY = yPos;
    }
  }
}

void touchUp(int ID, float xPos, float yPos, float xWidth, float yWidth){
  noFill();
  stroke(255,0,0);
  ellipse( xPos, yPos, xWidth * 2, yWidth * 2 );
  
  println("touch: " + xPos+" "+yPos);

  isDragLeft = false;
  isDragRight = false;
  if (isDrag) {
    ui.updateDataMax(yPos);
    isDrag = false;
  }
  //
  ui.updateCountryDisplay(xPos, yPos);

  //
  ui.updateCountryList(xPos, yPos);

  //
  ui.updateCountrySelector(xPos, yPos);

  //
  ui.updateDataSelector(xPos, yPos);

  //
  ui.updateTotalSelector(xPos, yPos);

  //
  ui.updateYearSelector(xPos, yPos);

  //
  ui.updatePieButton(xPos, yPos);

  //
  ui.updateMapWindow(xPos, yPos);

  //
  ui.updateSearchWindow(xPos, yPos);

  //
  ui.updateHelpWindow(xPos, yPos);

  //
  for (int i=0;i<DATA_SET_COUNT;i++) {
    legend[i].click(xPos, yPos, i);
  }

  //
  ui.updateTable(xPos, yPos);
  
  //
  ui.updateEvent(xPos, yPos);
}

void touchMove(int ID, float xPos, float yPos, float xWidth, float yWidth){
  if (isDragLeft) {
    ui.updateTimeLineL(xPos);
    //println("update");
  }
  if (isDragRight) {
    ui.updateTimeLineR(xPos);
    //println("update");
  }
}// touchMove

