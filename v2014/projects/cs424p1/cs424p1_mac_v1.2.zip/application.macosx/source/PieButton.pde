class PieButton {
  float x;
  float y;
  float h;
  float diff;
  
  int year;
  
  PieButton(float _x, float _y, float _h, float _diff) {
    x = _x;
    y = _y;
    h = _h;
    diff = _diff;
    
    year = yearMin;

  }
  public void render() {
    pushStyle();
    fill(127);
    noStroke();
    triangle(x, y, x, y+h, x - h*0.5, y + h*0.5);
    triangle(x+diff, y, x+diff, y+h, x+diff+h*0.5, y+h*0.5);
    popStyle();
  }
  public void update(float _x, float _y) {
    if (_y >= y && y <= y + h && _x >= x - h * 0.5 && _x <= x) {
      if (year > yearMin) year--;
    }

    if (_y>= y && _y <= y + h && _x >= x + diff && _x <= x + diff+h*0.5) {
      if (year < yearMax) year++;
    }
  }
  
  public int getYear() {
    return year;
  }
}

  
