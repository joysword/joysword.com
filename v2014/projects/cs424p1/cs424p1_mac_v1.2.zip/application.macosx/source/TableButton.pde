class TableButton {
  float x;
  float y;
  float h;
  float diff;
  
  int page;
  
  TableButton(float _x, float _y, float _h, float _diff) {
    x = _x;
    y = _y;
    h = _h;
    diff = _diff;
    
    page = 0;

  }
  public void render() {
    pushStyle();
    fill(127);
    noStroke();
    triangle(x, y, x, y+h, x - h*0.5, y + h*0.5);
    triangle(x+diff, y, x+diff, y+h, x+diff+h*0.5, y+h*0.5);
    popStyle();
  }
  public void update(float _x, float _y) {
    if (_y >= y && y <= y + h && _x >= x - h * 0.5 && _x <= x) {
      if (page > 0) page--;
    }

    if (_y>= y && _y <= y + h && _x >= x + diff && _x <= x + diff+h*0.5) {
      if (page < 2) page++;
    }
  }
  
  public int getPage() {
    return page;
  }
}

