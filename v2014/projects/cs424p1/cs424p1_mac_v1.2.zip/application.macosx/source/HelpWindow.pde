class HelpWindow
{
  float x;
  float y;
  float w;
  float h;
  
  float btnX;
  float btnY;
  float btnLen;
  
  boolean isActive;
  
  String helpContent;
  
  HelpWindow(float _x, float _y, float _w, float _h, String content, float bx, float by, float _len)
  {
    x = _x;
    y = _y;
    w = _w;
    h = _h;
    
    helpContent = content;
    
    isActive = false;
    
    btnX = bx;
    btnY = by;
    
    btnLen = _len;
    
  }

  public void render() {
    drawHelpButton();
    if (isActive)
    {
      pushStyle();
      stroke(0);
      fill(224);
      rectMode(CORNER);
      rect(x, y, w, h);
      fill(0);
      textAlign(CENTER, CENTER);
      textSize(16*scale);
      text(helpContent, (HELP_WINDOW_X1+HELP_WINDOW_X2)/2, (HELP_WINDOW_Y1+HELP_WINDOW_Y2)/2);
      popStyle();
    }
    pushStyle();
  }
  
  private void switchActive()
  {
    isActive = !isActive;
  }
  
  void drawHelpButton()
  {
    pushStyle();
    noStroke();
    fill(127);
    rectMode(CORNER);
    rect(btnX, btnY, btnLen, btnLen);
    fill(0);
    textSize(10*scale);
    textAlign(CENTER, CENTER);
    text("CREDITS", btnX+btnLen/2, btnY+btnLen/2);
    popStyle();
  }
  
  void update(float _x, float _y)
  {
    if (_x >= btnX && _x <= btnX+btnLen && _y >= btnY && _y <= btnY+btnLen) {
      switchActive();
    }
  }
  
  boolean getIsDisplay() {
    return isActive;
  }
}
