
class EventWindow {

  float btnX;
  float btnY;
  float btnLen;

  boolean isDisplay;

  EventWindow(float bx, float by, float bl) {

    btnX = bx;
    btnY = by;
    btnLen = bl;

    isDisplay = false;
  }

  public void render() {
    drawEventButton();
    if (isDisplay) {

      // China
      if (currentRow[0] == 193) {
        renderEvent(2001, "China Joined WTO");
      }
      // Eurasia
      else if (currentRow[0]>=95 && currentRow[0]<= 111) {

        renderEvent(1991, "U.S.S.R Collapsed");
      }
      // Cuba
      else if (currentRow[0] == 21) {

        renderEvent(1980, "Economic Blockage Underway");
      }
      // Iraq
      else if (currentRow[0] == 115) {

        renderEvent(1991, "Gulf War I");
        renderEvent(2003, "Gulf War II");
      }
    }
  }

  private void renderEvent(int year, String txt) {
    pushStyle();
    if (year!=1980) {
      if (year<showYearMin || year > showYearMax) return;
      float x = plotX1+(year-showYearMin+0.5) * (plotX2 - plotX1) / (showYearMax - showYearMin + 1);
      noFill();
      strokeWeight(2*scale);
      stroke(color(50, 50, 50, 200));
      line(x, plotY2, x, plotY1-2*scale);
      textSize(15*scale);
      textAlign(CENTER, BASELINE);
      text(txt, x, plotY1);
    }
    //Cuba
    else {
      float x = plotX1 + 0.5 * (plotX2 - plotX1) / (showYearMax - showYearMin + 1);
      float x2= plotX2 - 0.5 * (plotX2 - plotX1) / (showYearMax - showYearMin + 1);
      noFill();
      strokeWeight(2*scale);
      stroke(color(50, 50, 50, 200));
      line(x, plotY2, x, plotY1);
      line(x2, plotY2, x2, plotY1);
      textSize(15*scale);
      textAlign(CENTER, BASELINE);
      text(txt, (x+x2)/2, plotY1);
    }

    popStyle();
  }

  public void drawEventButton() {
    pushStyle();
    noStroke();
    fill(127);
    rectMode(CORNER);
    rect(btnX, btnY, btnLen, btnLen);
    fill(0);
    textSize(10*scale);
    textAlign(CENTER, CENTER);

    text("EVENTS", btnX+btnLen/2, btnY+btnLen/2);
    popStyle();
  }

  private void switchDisplay()
  {
    isDisplay = !isDisplay;
  }

  public void update(float _x, float _y) {
    if (_x >= btnX && _x <= btnX+btnLen && _y >= btnY && _y <= btnY+btnLen) {
      switchDisplay();
    }
    if (ui.getDisplayMode() == MULTI_COUNTRY_MODE || ui.getYearMode() == DECADE_MODE || ui.getTable().getIsDisplay()) {
      setNotDisplay();
    }
  }

  public void setNotDisplay()
  {
    isDisplay = false;
  }

  public boolean getIsDisplay()
  {
    return isDisplay;
  }
}

