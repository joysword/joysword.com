String str1 = "QWERTYUIOP";
String str2 = "ASDFGHJKL";
String str3 = "ZXCVBNM";
char[] keyText1 = str1.toCharArray();
char[] keyText2 = str2.toCharArray();
char[] keyText3 = str3.toCharArray();

final float KEY_LEN = 34*scale;
final float KEY_TAB = 10*scale;
final float KEY_DIFF = 6*scale;

class Keyboard {
  
  float x, y;
  float tab;
  float len; // length of each key
  float diff;
  
  Keyboard(float _x, float _y) {
    x = _x;
    y = _y;
    
    len = KEY_LEN;
    tab = KEY_TAB;
    diff = KEY_DIFF;
  }
  
  public void render() {
    pushStyle();
    
    
    //translate(x,y);
    stroke(0);
    noFill();
    rectMode(CORNER);
    textSize(25*scale);
    textAlign(CENTER, CENTER);
    
    // 1st line QWERTYUIOP
    for (int i=0;i<10;i++) {
      rect(x+i*(len+diff), y, len, len);
      fill(0);
      text(keyText1[i], x+i*(len+diff)+len/2, y+len/2);
      noFill();
    }
    
    // BACKSPACE
    rect(x+10*(len+diff), y, 1.5*len, len);
    fill(0);
    text("<=", x+10*(len+diff)+len*0.75, y+len/2);
    noFill();
    
    // 2nd line ASDFGHJKL
    for (int i=0;i<9;i++) {
      rect(x+i*(len+diff)+tab, y+len+diff, len, len);
      fill(0);
      text(keyText2[i], x+i*(len+diff)+tab+len/2, y+len+diff+len/2);
      noFill();
    }
    
    // ENTER
    rect(x+9*(len+diff)+tab, y+len+diff, 2*len, len);
    fill(0);
    textSize(15*scale);
    text("     ENTER", x+9*(len+diff)+tab+len/2, y+len+diff+len/2);
    noFill();
    
    textSize(25*scale);
    // 3rd line ZXCVBNM
    for (int i=0;i<7;i++) {
      rect(x+i*(len+diff)+2.5*tab, y+(len+diff)*2, len, len);
      fill(0);
      text(keyText3[i], x+i*(len+diff)+2.5*tab+len/2, y+(len+diff)*2+len/2);
      noFill();
    }
      
      
    popStyle();
  }
  
  public int update(float _x, float _y) {
    for (int i=0;i<10;i++) {
      if (inside(x+i*(len+diff), y, len, len, _x, _y)) {
        println((int)keyText1[i]);
        return (int) keyText1[i];
      }
    }
    for (int i=0;i<9;i++) {
      if (inside(x+i*(len+diff)+tab, y+len+diff, len, len, _x, _y)) {
        println((int)keyText2[i]);
        return (int) keyText2[i];
      }
    }
    for (int i=0;i<7;i++) {
      if (inside(x+i*(len+diff)+2.5*tab, y+(len+diff)*2, len, len, _x, _y)) {
        println((int)keyText3[i]);
        return (int) keyText3[i];
      }
    }
    if (inside(x+10*(len+diff), y, 1.5*len, len, _x, _y)) {
      return WRONG;
    }
      
    if (inside(x+9*(len+diff)+tab, y+len+diff, 2*len, len, _x, _y)) {
      return ZHONG;
    }
    
    return 0;
 }
 
 private boolean inside(float x, float y, float w, float h, float posx, float posy) {
   return (posx >= x && posx <= x+w && posy >= y && posy <= y + h)? true:false;
 }
 
 public float getKeyLen() {
   return len;
 }
 
}
