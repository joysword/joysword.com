/*void mousePressed() {
  if (ui.getTableWindow().getIsDisplay() == false) {
    if (mouseX >= ui.getTimeLine().getLeftLock().getX()-TIME_LOCK_W-8*scale && mouseX <= ui.getTimeLine().getLeftLock().getX()+TIME_LOCK_W+8*scale
      && mouseY >= ui.getTimeLine().getLeftLock().getY()-TIME_LOCK_H-8*scale && mouseY <= ui.getTimeLine().getLeftLock().getY()+TIME_LOCK_H+8*scale)
    {
      isDragLeft = true;
      //println(isDragLeft);
    } 
    else if (mouseX >= ui.getTimeLine().getRightLock().getX()-TIME_LOCK_W-8*scale && mouseX <= ui.getTimeLine().getRightLock().getX()+TIME_LOCK_W+8*scale
      && mouseY >= ui.getTimeLine().getRightLock().getY()-TIME_LOCK_H-8*scale && mouseY <= ui.getTimeLine().getRightLock().getY()+TIME_LOCK_H+8*scale)
    {
      isDragRight = true;
      //println(isDragRight);
    }
    if (mouseX > plotX1 && mouseX < plotX2 && mouseY > plotY1 && mouseY < plotY2) {
      isDrag = true;
      dragStartY = mouseY;
    }
  }
}

void mouseDragged() {
  if (isDragLeft) {
    ui.updateTimeLineL(mouseX);
    //println("update");
  }
  if (isDragRight) {
    ui.updateTimeLineR(mouseX);
    //println("update");
  }
}

void mouseReleased() {
  println("mouse: " + mouseX+" "+mouseY);

  isDragLeft = false;
  isDragRight = false;
  if (isDrag) {
    ui.updateDataMax(mouseY);
    isDrag = false;
  }
  //
  ui.updateCountryDisplay(mouseX, mouseY);

  //
  ui.updateCountryList(mouseX, mouseY);

  //
  ui.updateCountrySelector(mouseX, mouseY);

  //
  ui.updateDataSelector(mouseX, mouseY);

  //
  ui.updateTotalSelector(mouseX, mouseY);

  //
  ui.updateYearSelector(mouseX, mouseY);

  //
  ui.updatePieButton(mouseX, mouseY);

  //
  ui.updateMapWindow(mouseX, mouseY);

  //
  ui.updateSearchWindow(mouseX, mouseY);

  //
  ui.updateHelpWindow(mouseX, mouseY);

  //
  for (int i=0;i<DATA_SET_COUNT;i++) {
    legend[i].click(mouseX, mouseY, i);
  }

  //
  ui.updateTable(mouseX, mouseY);
  
  //
  ui.updateEvent(mouseX, mouseY);
}*/

