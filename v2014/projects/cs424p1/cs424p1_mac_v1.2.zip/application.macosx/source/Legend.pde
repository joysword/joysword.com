class Legend {
  float x;
  float y;
  String str;
  int colour;
  
  float w;
  
  Legend(float _x, float _y, float _w, String _s, int c) {
    x = _x;
    y = _y;
    w = _w;
    str = _s;
    colour = c;
  }
  
  public void render() {
    pushStyle();
    fill(colour);
    noStroke();
    rectMode(CORNER);
    rect(x,y,w,w);
    fill(0);
    textAlign(LEFT, CENTER);
    text(str, x+w+2*scale, y+w*0.5);
  }
  
  public void update(int i) {
    if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
      str = ui.dataSelector[i].getTxt()+"\n"+unitText[i];
    } else if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
      if (currentDisplay[i] == true) {
        str = countryNames[currentRow[i]];
      } else {
        str = "";
      }
    }
  }
  
  public void updateString(String strr) {
    str = strr;
  }
  
  public void click(float _x, float _y, int number) {
    if (_x >= x && _x <= x+110*scale && _y>=y && _y<=y+w) {
      if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
        if (ui.getSearchWindow().getIsDisplay() == false && ui.getMapWindow().getIsDisplay() == false && ui.getTableWindow().getIsDisplay() == false && ui.getHelpWindow().getIsDisplay() == false) {
          currentDisplay[number] = false;
          str = "";
        }
      }
      if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
        if (ui.getSearchWindow().getIsDisplay() == false && ui.getMapWindow().getIsDisplay() == false && ui.getTableWindow().getIsDisplay() == false && ui.getHelpWindow().getIsDisplay() == false) {
          displayVolume = number;
        }
      }
    }
    ui.updateDataForPieChart();
  }
}
