////////////////////////////////////////////////////////////////////////// 
import processing.net.*;
import omicronAPI.*;

OmicronAPI omicronManager;
TouchListener touchListener;

// Link to this Processing applet - used for touchDown() callback example
PApplet applet;

// Override of PApplet init() which is called before setup()
public void init() {
  super.init();

  // Creates the OmicronAPI object. This is placed in init() since we want to use fullscreen
  omicronManager = new OmicronAPI(this);

  // Removes the title bar for full screen mode (present mode will not work on Cyber-commons wall)
  //omicronManager.setFullscreen(true);
}
///////////////////////////////////////////////////
UserInterface ui;

//resolution
//final int scale = 5;
final int scale = 1;
// 5 for cyber-commons
// 1 for full screen macbook

final int Width = 1632;
final int Height = 461;

//final int Width = 1440;
//final int Height = 460;

//final int Width = 8160;
//final int Height = 2304;

//ArrayList li = new ArrayList();

//IndexedList inli = new IndexedList();

//DropBox dropBox;

//Range range;

float dataMin;
float[] dataMax;
float[] originalDataMax;

int[] currentRow = {
  6, 6, 6, 6, 6, 6, 6
};
boolean[] currentDisplay = {
  true, false, false, false, false, false, false
};

int yearInterval = 10;

Integrator[] interpolators;

int i = 0;

float[] spacing = new float[2];

Legend[] legend;

boolean isDragLeft = false;
boolean isDragRight = false;

boolean isDrag = false;
float dataScale = 1;
float dragStartY;

// which Volume at Y axis is being displayed
int displayVolume = 0;

String[] unitText;
///////////////////////////////////
//
//
//                  SETUP
//
//
///////////////////////////////////
void setup()
{
  //size(Width*scale, Height*scale);
  size(Width, Height);
  //Make the connection to the tracker machine (uncomment this if testing with touch)
  //omicronManager.ConnectToTracker(7001, 7340, "131.193.77.159");

  // Create a listener to get events
  touchListener = new TouchListener();

  // Register listener with OmicronAPI
  omicronManager.setTouchListener(touchListener);

  // Sets applet to this sketch
  applet = this;


  //load in data sets
  setupData(); 

  /*
  interpolators = new Integrator[columnCount];
   
   for (int column = 0; column < columnCount; column++) {
   float initialValue = data.getFloat(0, column);
   interpolators[column] = new Integrator(initialValue);
   interpolators[column].attraction = 0.1;
   }*/

  // setup Font
  plotFont = createFont("Verdana", 10*scale);
  textFont(plotFont);

  // setup Colors
  colors = new int[] {
    COLOR_0, COLOR_1, COLOR_2, COLOR_3, COLOR_4, COLOR_5, COLOR_6
  };

  defaultColor = new int[][] {
    {
      colors[0], DEFAULT_PIE_COLOR
    }
    , {
      colors[1], DEFAULT_PIE_COLOR
    }
    , {
      colors[2], color(100)
    }
    , {
      colors[3], DEFAULT_PIE_COLOR
    }
    , {
      colors[4], color(100)
    }
    , {
      colors[5], DEFAULT_PIE_COLOR
    }
    , {
      colors[6], DEFAULT_PIE_COLOR
    }
  };

  for (int i=0;i<DATA_SET_COUNT;i++) {
    defaultColor[i][0] = colors[i];
    defaultColor[i][1] = DEFAULT_PIE_COLOR;
  }

  unitText = new String[] {
    "(Quads)", "(Quads)", "(Quads/C)", "(MMT)", "(MT/C)", "(BkWh)", "(Millions)"
  };


  setupPlotAndTable();

  YEAR_SELECTOR_X = plotX1 + (plotX2 - plotX1) * 0.2;

  ui = new UserInterface();

  //used by dashline
  setupDashLine(DASH_LINE_SPACING1, DASH_LINE_SPACING2);

  //dropBox= new DropBox(1, 1, 120, 10, li, inli, 0);
  //dropBox= new DropBox(1, 1, 120);

  legend = new Legend[DATA_SET_COUNT];
  for (int i=0;i<DATA_SET_COUNT;i++) {
    legend[i] = new Legend(PAGE_BTN_X+PAGE_BTN_W+LEGEND_DIFF, LIST_Y + (i - 1)*2.1*LIST_LINE_H + 12*scale, LIST_LINE_H, ui.dataSelector[i].getTxt()+"\n"+unitText[i], colors[i]);
  }

  // setup Pie Charts
  pieChart = new PieChart[DATA_SET_COUNT];
  for (int i=0;i<DATA_SET_COUNT;i++) {
    float[] data = new float[2];
    data[0] = dataSets[i].getData().getFloat(currentRow[0], ui.getPieButton().getYear()-yearMin);
    data[1] = dataSets[i].getData().getFloat(getRegion(currentRow[0]), ui.getPieButton().getYear()-yearMin);

    pieChart[i] = new PieChart(data, 2, defaultColor[i], PIE_CHART_X, PIE_CHART_Y+ i * PIE_CHART_DIS, PIE_CHART_R, i);
  }
  pieChart[0].setDisplay();

  smooth();
} // end of setup


///////////////////////////////////
//
//
//                  DRAW
//
//
///////////////////////////////////
void draw() {
  background(224);

  if (ui.getShowTable() == false) {
    //draw PLOT and Bar
    drawPlotAndBar();
  }
  else {
    ui.getTable().render();
  }
  //draw Legend
    for (int i=0;i<DATA_SET_COUNT;i++) {
      legend[i].render();
    }

    //draw pie Title
    drawPieTitle();
    //draw Pie Charts
    drawPieCharts();

//draw Title
    if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
      drawTitle(countryNames[currentRow[0]]);
    }
    if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
      int i=0;
      while (i<DATA_SET_COUNT && ui.getDataSelector(i).getCheck() == false) i++;
      if (i<DATA_SET_COUNT)
      {
        drawTitle(ui.getDataSelector(i).getTxt()+ " " + unitText[i]);
      }
    }

//draw User Interface
ui.render();

omicronManager.process();
}

void drawTitle(String st) {
  pushStyle();
  fill(0);
  textSize(12*scale);
  textAlign(LEFT, TOP);
  if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
    if (ui.getYearMode() == YEAR_MODE) {
      text("One Country Mode,   Year by year", SEARCH_BUTTON_LEN * 0.2, 10*scale);
    }
    if (ui.getYearMode() == DECADE_MODE) {
      text("One Country Mode,   Decades average", SEARCH_BUTTON_LEN * 0.2, 10*scale);
    }
  }
  if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
    if (ui.getYearMode() == YEAR_MODE) {
      text("Multi Countries Compare,   Year by year", SEARCH_BUTTON_LEN * 0.2, 10*scale);
    }
    if (ui.getYearMode() == DECADE_MODE) {
      text("Multi Countries Compare,   Decades average", SEARCH_BUTTON_LEN * 0.2, 10*scale);
    }
  }
  textSize(24*scale);
  text(st, SEARCH_BUTTON_LEN * 0.5, 30*scale);
  popStyle();
}

///////////////////
///////////////////
/////////////////////////////////////////////////////////
///////////////////
///////////////////      SETUP_DATA
///////////////////
/////////////////////////////////////////////////////////
///////////////////
///////////////////
void setupData()
{
  
  dataMax = new float[DATA_SET_COUNT];
  originalDataMax = new float[DATA_SET_COUNT];
  
  dataSets = new DataSets[DATA_SET_COUNT];

  dataSets[0] = new DataSets("Total_Primary_Energy_Production.txt");
  dataSets[1] = new DataSets("Total_Primary_Energy_Consumption.txt");
  dataSets[2] = new DataSets("Total_Primary_Energy_Consumption_Per_Capita.txt");
  dataSets[3] = new DataSets("Total_CO2_Emission.txt");
  dataSets[4] = new DataSets("Total_CO2_Per_Capita.txt");
  dataSets[5] = new DataSets("Total_Renewable_Electricity_Net_Generation.txt");
  dataSets[6] = new DataSets("Population.txt");
  
  dataSets[0].setInterval(500);
  dataSets[1].setInterval(500);
  dataSets[2].setInterval(500);
  dataSets[3].setInterval(500);
  dataSets[4].setInterval(500);
  dataSets[5].setInterval(500);
  dataSets[6].setInterval(500);

  rowCount = dataSets[0].getData().getRowCount();
  columnCount = dataSets[0].getData().getColumnCount();

  years = int(dataSets[0].getData().getColumnNames());

  yearMin = years[0];
  yearMax = years[years.length-1];

  showYearMin = yearMin;
  showYearMax = yearMax;

  countryNames = dataSets[0].getData().getRowNames();
}

void setupPlotAndTable()
{
  plotX1 = 510*scale;
  plotX2 = Width - 220*scale;
  
  TABLE_WINDOW_X = plotX1-30*scale;
  TABLE_PAGE_BTN_X = plotX2-TABLE_PAGE_BTN_H*0.5-TABLE_PAGE_BTN_DIFF;

  plotY1 = 45*scale;
  plotY2 = Height - 120*scale;

  labelX = plotX1 - 35*scale;

  tableY1 = plotY2+20*scale;
  tableY2 = (Height - 60)*scale;

  yearCount = showYearMax-showYearMin+1;

  unitWidth = (plotX2-plotX1)/yearCount;

  displayNumber = DATA_SET_COUNT;

  unitHeight = (tableY2-tableY1)/displayNumber;

  dataMin = 0;
  for (int i=0;i<DATA_SET_COUNT;i++) {
    dataMax[i] = ceil(dataSets[i].getData().getTableMax()/dataSets[i].getInterval())*dataSets[i].getInterval();
    originalDataMax[i] = dataMax[i];
  }

  //setupDecade();
}


void setupDashLine(float sp1, float sp2) {
 spacing[0] = sp1;
 spacing[1] = sp2;
 }

void drawPlotAndBar()
{
  yearCount = showYearMax-showYearMin+1;
  unitWidth = (plotX2-plotX1)/yearCount;
  if (ui.getYearMode() == YEAR_MODE) {
    drawPlot();
  }
  else if (ui.getYearMode() == DECADE_MODE) {
    drawBar();
  }
  //drawTabular(yearCount, displayNumber);
}

void drawPlot() {
  pushStyle();
  fill(245);
  rectMode(CORNERS);
  noStroke();
  rect(plotX1, plotY1, plotX2, plotY2);

  //drawAxisLabels();
  /*
  for (int column = 0; column < columnCount; column++) {
   interpolators[column].update();
   }*/

  drawYearLabels();

  noFill();
  strokeWeight(2*scale);

//////
//
//
//
//
//
//  volumeeeeee
//
//
//
///////
  //multi countries
  if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
    for (int i = 0; i < DATA_SET_COUNT; i ++) {
      if (ui.dataSelector[i].getCheck() == true) { 
        drawVolumeLabels(i);
        break;
      }
    }
  }
  
  //one country, many data sets
  if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
    int cnt = 0;
    for (int i=0;i < DATA_SET_COUNT;i++) {
      if (ui.dataSelector[i].getCheck() == true) {
        cnt++;
      }
    }
    // only 1 data set is being displayed
    if (cnt == 1) {
      for (int i=0;i<DATA_SET_COUNT;i++) {
        if (ui.dataSelector[i].getCheck() == true) {
          drawVolumeLabels(i);
          break;
        }
      }
    }
    else {
      drawVolumeLabels(displayVolume);
    }
  }    
  
  
  
 //////////END OF VOLUME

  if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
    for (int i = 0; i < DATA_SET_COUNT; i ++) {
      if (ui.dataSelector[i].getCheck() == true) {
        drawDataCurve(currentRow[0], i, i, showYearMin, showYearMax);
        
        
        // special cases
        
        if (isNansilafu(currentRow[0])) {
          //slavia
          if (currentRow[0] == 67) {
            drawDataCurveDashSpecial(new int[]{79,89,57,59,66},i,i,showYearMin,showYearMax,1992,2005);
            drawDataCurveDashSpecial(new int[]{79,89,57,59,92,86},i,i,showYearMin,showYearMax,2006,2009);
          }
          else {
            drawDataCurveDash(67,i,i,showYearMin,showYearMax,1980,1991);
            if (currentRow[0] == 66) {
             drawDataCurveDashSpecial(new int[]{92,86},i,i,showYearMin,showYearMax,2006,2009);
            }
            else if (currentRow[0] == 92 || currentRow[0] == 86) {
                drawDataCurveDash(66,i,i,showYearMin,showYearMax,1992,2005);
            }
          }
        }
        else if (isGermany(currentRow[0])) {
          // Germany
          if (currentRow[0] == 69) {
            drawDataCurveDashSpecial(new int[]{70,71},i,i,showYearMin,showYearMax,1980,1990);
          }
          // East or West
          else {
            drawDataCurveDash(69,i,i,showYearMin,showYearMax,1991,2009);
          }
        }
        else if (isCzechSlovakia(currentRow[0])) {
          // Czechoslovakia
          if (currentRow[0] == 65) {
            drawDataCurveDashSpecial(new int[]{61,88},i,i,showYearMin,showYearMax,1993,2009);
          }
          // Czech Slovakia
          else {
            drawDataCurveDash(65, i,i,showYearMin,showYearMax, 1980,1992);
          }
          
        }
        else if (isUSSR(currentRow[0])) {
          // USSR
          if (currentRow[0] == 100) {
            drawDataCurveDash(95, i,i, showYearMin,showYearMax, 1992, 2009);
          }
          // new countries
          else {
            drawDataCurveDash(100,i,i,showYearMin,showYearMax, 1980, 1991);
          }
        }
      }
    }
  }

  if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
    for (int i = 0; i < DATA_SET_COUNT; i++) {
      if (ui.dataSelector[i].getCheck() == true) {
        for (int j=0;j < DATA_SET_COUNT; j++) {
          if (currentDisplay[j] == true) {
            drawDataCurve(currentRow[j], j, i, showYearMin, showYearMax);
          }
        }
      }
    }
  }

  //drawDataHighlight(currentRow, i);
  //drawDataHighlight(currentRow2);
  popStyle();
}

void drawBar() {
  pushStyle();
  fill(245);
  rectMode(CORNERS);
  noStroke();
  rect(plotX1, plotY1, plotX2, plotY2);

  fill(0);
  textSize(10*scale);
  textAlign(CENTER);

  // Use thin, gray lines to draw the grid
  stroke(0);
  strokeWeight(scale);
  float left = plotX1;
  float right = left + (plotX2-plotX1)/3.0;
  for (int column = 0; column < 30; column+=10) {
    float x = (left+right)/2;
    text(years[column] + " - " + years[column+9], x, plotY2 + textAscent() + 5*scale);
    if (column + 10 < yearMax) {
      line(right, plotY2, right, plotY2+3*scale);
    }
    left = right;
    right += (plotX2-plotX1)*0.33;
  }

  noFill();
  strokeWeight(2*scale);

  if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
    for (int i = 0; i < DATA_SET_COUNT; i ++) {
      if (ui.dataSelector[i].getCheck() == true) { 
        drawVolumeLabels(i);
        break;
      }
    }
  }
  
  //one country, many data sets
  if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
    int cnt = 0;
    for (int i=0;i < DATA_SET_COUNT;i++) {
      if (ui.dataSelector[i].getCheck() == true) {
        cnt++;
      }
    }
    // only 1 data set is being displayed
    if (cnt == 1) {
      for (int i=0;i<DATA_SET_COUNT;i++) {
        if (ui.dataSelector[i].getCheck() == true) {
          drawVolumeLabels(i);
          break;
        }
      }
    }
    else {
      drawVolumeLabels(displayVolume);
    }
  }

  if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {
    for (int i = 0; i < DATA_SET_COUNT; i ++) {
      if (ui.dataSelector[i].getCheck() == true) {
        //drawDataCurve(currentRow[0], i, showYearMin, showYearMax);
        drawDataBar(currentRow[0], i, i);
      }
    }
  }

  if (ui.getDisplayMode() == MULTI_COUNTRY_MODE) {
    for (int i = 0; i < DATA_SET_COUNT; i++) {
      if (ui.dataSelector[i].getCheck() == true) {
        for (int j=0;j < DATA_SET_COUNT; j++) {
          if (currentDisplay[j] == true) {
            //drawDataCurve(currentRow[j], j, showYearMin, showYearMax);
            drawDataBar(currentRow[j], i, j);
          }
        }
        break;
      }
    }
  }
  popStyle();
}

void drawAxisLabels() {
  pushStyle();
  fill(0);
  textSize(13*scale);
  textLeading(15);

  textAlign(RIGHT, CENTER);
  text("What\nthe\nX", labelX, (plotY1+plotY2)/2);
  textAlign(CENTER);
  //text("What the Y", (plotX1+plotX2)/2, labelY);
  popStyle();
}

void drawYearLabels() {
  pushStyle();

  fill(0);
  textSize(10*scale);
  textAlign(CENTER);

  // Use thin, gray lines to draw the grid
  stroke(0);
  strokeWeight(scale);

  float left = plotX1;
  float right = left+unitWidth;

  for (int column = showYearMin-yearMin; column < showYearMax-yearMin+1; column++) {
    float x = (left+right)/2;
    if (showYearMax-showYearMin+1 <=15)
    {
      text(years[column], x, plotY2 + textAscent() + 5*scale);
    }
    else if (column%2 == 0) {
      text(years[column], x, plotY2 + textAscent() + 5*scale);
    }
    line(x, plotY2, x, plotY2+3*scale);
    left = right;
    right += unitWidth;
  }

  popStyle();
}


void drawVolumeLabels(int i) {

  pushStyle();
  fill(0);
  textSize(10*scale);
  textAlign(RIGHT);

  stroke(224);
  strokeWeight(1);

  //for (float v = dataMin; v <= dataMax[i]; v += volumeInterval[i]) {
  for (float v = dataMin; v < dataMax[i]*dataScale; v += (dataMax[i]*dataScale-dataMin)/15) {

    float y = map(v, dataMin, dataMax[i]*dataScale, plotY2, plotY1);  
    float textOffset = textAscent()/2;  // Center vertically
    if (v == dataMin) {
      textOffset = 0;                   // Align by the bottom
    } 
    else if (v == dataMax[i]) {
      textOffset = textAscent();        // Align by the top
    }
    text(round(v), plotX1 - 10, y + textOffset);
    line(plotX1, y, plotX2, y);     // Draw major tick
  }
  popStyle();
}

void drawDataCurve(int row, int colour, int i, int yMin, int yMax) {
  pushStyle();

  noFill();
  stroke(colors[colour]);

  beginShape();
  float left = plotX1;
  float right = left+unitWidth;

  for (int col = showYearMin-yearMin; col < showYearMax-yearMin+1; col++) {

    if (dataSets[i].getData().isValid(row, col)) {
      float value = dataSets[i].getData().getFloat(row, col);
      float x = (left+right)/2;
      float y = map(value, dataMin, dataMax[i]*dataScale, plotY2, plotY1);
      ellipse(x, y, 3*scale, 4*scale);

      vertex(x, y);
      // double the curve points for the start and stop
      /*if (starting == false || col == columnCount-1) {
       starting = true; 
       curveVertex(x, y);
       }*/
    }
    left = right;
    right += unitWidth;
  }
  endShape();

  popStyle();
}

void drawDataBar(int row, int table, int col) {
  pushStyle();

  fill(colors[col]);
  //noFill();
  noStroke();
  int left = 0;
  int right = 10;
  float amount = 0;
  boolean isValid = true;
  float barWidth = 18*scale;

  // 11111111
  for (int i=left;i<right;i++) {
    if (dataSets[table].getData().isValid(row, i)) {
      amount += dataSets[table].getData().getFloat(row, i);
    } 
    else
    {
      isValid = false;
      break;
    }
  }
  if (isValid) {
    rectMode(CORNERS);
    amount = amount * 0.1;
    float xx = plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth*(3-col);
    float yy = map(amount, dataMin, dataMax[table]*dataScale, plotY2, plotY1);
    //println("table:" + table + ",,,  " + xx + "  " + yy);
    rect(xx, yy, xx+barWidth, plotY2);
    /*
    
     stroke(0);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, plotY2);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, plotY2);
     stroke(colors[table]);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, yy);*/
  }

  // 2222222
  left += 10;
  right += 10;
  amount = 0;
  isValid = true;
  for (int i=left;i<right;i++) {
    if (dataSets[table].getData().isValid(row, i)) {
      amount += dataSets[table].getData().getFloat(row, i);
    } 
    else
    {
      isValid = false;
      break;
    }
  }

  if (isValid) {
    rectMode(CORNERS);
    amount = amount * 0.1;
    //rect(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, map(amount, dataMin, dataMax[table], plotY2, plotY1), plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, plotY2);
    float xx = plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth*(3-col);
    float yy = map(amount, dataMin, dataMax[table]*dataScale, plotY2, plotY1);
    rect(xx, yy, xx+barWidth, plotY2);
    /*
    stroke(0);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, plotY2);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, plotY2);
     stroke(colors[table]);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, yy);*/
  }

  // 3333333
  left += 10;
  right += 10;
  amount = 0;
  isValid = true;
  for (int i=left;i<right;i++) {
    if (dataSets[table].getData().isValid(row, i)) {
      amount += dataSets[table].getData().getFloat(row, i);
    } 
    else
    {
      isValid = false;
      break;
    }
  }

  if (isValid) {
    rectMode(CORNERS);
    amount = amount * 0.1;
    //rect(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, map(amount, dataMin, dataMax[table], plotY2, plotY1), plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, plotY2);
    float xx = plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth*(3-col);
    float yy = map(amount, dataMin, dataMax[table]*dataScale, plotY2, plotY1);
    rect(xx, yy, xx+barWidth, plotY2);
    /*
    stroke(0);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, plotY2);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, plotY2);
     stroke(colors[table]);
     line(plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) - barWidth, yy, plotX1 + (1+left*0.2)/6.0*(plotX2-plotX1) + barWidth, yy);*/
  }
}
void drawDataCurveDash(int row, int colour, int i, int yMin, int yMax, int begin, int end) {
  pushStyle();

  noFill();
  stroke(colors[colour]);

  float[][] dashPoint = new float[columnCount][2];
  
  float left = plotX1;
  float right = left+unitWidth;

  for (int col = showYearMin-yearMin; col < showYearMax-yearMin+1; col++) {
    if (dataSets[i].getData().isValid(row, col) && col>=begin-1980 && col<=end-1980) {
      float value = dataSets[i].getData().getFloat(row, col);
      float x = (left+right)/2;
      float y = map(value, dataMin, dataMax[i]*dataScale, plotY2, plotY1);
      dashPoint[col][0] = x;
      dashPoint[col][1] = y;
      ellipse(x, y, 3*scale, 4*scale);
    }
    else {
      dashPoint[col][0] = -1000;
      dashPoint[col][1] = -1000;
    }
    
    left = right;
    right += unitWidth;
  }

  for (int col = showYearMin-yearMin+1; col < showYearMax-yearMin+1; col++) {
    if (dashPoint[col-1][0] != -1000 && dashPoint[col][0] != -1000)
      dashline(dashPoint[col-1][0], dashPoint[col-1][1], dashPoint[col][0], dashPoint[col][1], spacing);
  }

  popStyle();  
}

void drawDataCurveDashSpecial(int[] row, int colour, int i, int yMin, int yMax, int begin, int end) {
  pushStyle();

  noFill();
  stroke(colors[colour]);

  float[][] dashPoint = new float[columnCount][2];
  
  float left = plotX1;
  float right = left+unitWidth;
  
  int ct = row.length;

  for (int col = showYearMin-yearMin; col < showYearMax-yearMin+1; col++) {
    if (col>=begin-1980 && col<=end-1980) {
      float value = 0;
      for (int j=0;j<ct;j++) {
        value += dataSets[i].getData().getFloat(row[j], col);
      }
      float x = (left+right)/2;
      float y = map(value, dataMin, dataMax[i]*dataScale, plotY2, plotY1);
      dashPoint[col][0] = x;
      dashPoint[col][1] = y;
      ellipse(x, y, 3*scale, 4*scale);
    }
    else {
      dashPoint[col][0] = -1000;
      dashPoint[col][1] = -1000;
    }
    
    left = right;
    right += unitWidth;
  }

  for (int col = showYearMin-yearMin+1; col < showYearMax-yearMin+1; col++) {
    if (dashPoint[col-1][0] != -1000 && dashPoint[col][0] != -1000)
      dashline(dashPoint[col-1][0], dashPoint[col-1][1], dashPoint[col][0], dashPoint[col][1], spacing);
  }

  popStyle();  
}

void drawTabular(int rowC, int lineC) {
  pushStyle();
  fill(245);
  rectMode(CORNERS);
  stroke(0);
  strokeWeight(scale);
  rect(plotX1, tableY1, plotX2, tableY2);

  //draw vertical lines
  float xx = plotX1+unitWidth;

  while (xx<plotX2)
  {
    line(xx, tableY1, xx, tableY2);
    xx+=unitWidth;
  }

  //draw horizontal lines
  float yy = tableY1+unitHeight;

  while (yy<tableY2)
  {
    line(plotX1, yy, plotX2, yy);
    yy+=unitHeight;
  }

  popStyle();
}

void drawPieCharts() {
  if (ui.getDisplayMode() == ONE_COUNTRY_MODE)
  {
    for (int i=0;i<DATA_SET_COUNT; i++)
    {
      if (pieChart[i].getIsDisplay()) {
        pieChart[i].render();
      }
      // update color and data for pie charts

      // draw pieChart
    }
  }
  else // MULTI_COUNTRY_MODE
  {
    pieChart[0].render();
  }
}

int getRegion(int i)
{
  if (ui.getPieChartMode() == REGION_MODE)
  {
    if (i<7) {
      return 0;
    } 
    else if (i<53) {
      return 7;
    } 
    else if (i<95) {
      return 53;
    } 
    else if (i<112) {
      return 95;
    } 
    else if (i<127) {
      return 112;
    } 
    else if (i<184) {
      return 127;
    } 
    else if (i<rowCount-1) {
      return 184;
    }
  }
  return rowCount-1;
}

void drawPieTitle() {
  pushStyle();
  textSize(15*scale);
  textAlign(LEFT, CENTER);
  if (ui.displayMode == ONE_COUNTRY_MODE) {
    if (ui.getPieChartMode() == REGION_MODE) {
      text("Compare to Region", Width - 200*scale, 15*scale);
    }
    else {
      text("Compare to World", Width - 200*scale, 15*scale);
    }
  }
  else { //MULTI_COUNTRY_MODE
    text("Compare to each other", Width - 200*scale, 15*scale);
  }
  textAlign(RIGHT, CENTER);
  textSize(12*scale);
  text("("+ui.getPieButton().getYear()+")", Width - 10*scale, 30*scale);
  popStyle();
}
