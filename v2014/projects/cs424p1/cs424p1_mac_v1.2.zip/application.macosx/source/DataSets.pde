class DataSets {
  FloatTable data;
  int volumeInterval;
  
  //Constructor
  DataSets (String str) // str is the file name
  {
    data = new FloatTable(str);
    volumeInterval = -1;
  }
  
  public void setupData(String str)
  {
    data = new FloatTable(str);
  }
  
  public void setInterval(int i)
  {
    volumeInterval = i;
  }
  
  public FloatTable getData()
  {
    return data;
  }
  
  public int getInterval()
  {return volumeInterval;}
}
