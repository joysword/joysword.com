
class MapWindow {
  float x;
  float y;
  
  float capHeight;
  float w;
  float winHeight;
  
  String caption;
  
  float btnX;
  float btnY;
  float btnLen;
  
  PImage worldmap;
  
  boolean isDisplay;
  
  MapWindow(float _x, float _y, float wid, String cap, float cH, float wH, float bx, float by, float bl) {
    
    x = _x;
    y = _y;
    w = wid;
    caption = cap;
    capHeight = cH;
    winHeight = wH;

    worldmap = loadImage("map.png");
    worldmap.resize((int)w-1, (int)(winHeight)-1);    
    
    btnX = bx;
    btnY = by;
    btnLen = bl;

    isDisplay = false;
  }
  
  public void render() {
    drawMapButton();
    if (isDisplay) {
      pushStyle();
      fill(202);
      stroke(0);
      rectMode(CORNER);
      rect(x, y, w, capHeight+winHeight);
      line(x, y+capHeight, x+w, y+capHeight);
      textAlign(CENTER, CENTER);
      fill(0);
      textSize(25*scale);
      text(caption, x+0.5*w, y+0.5*capHeight);
      popStyle();
      image(worldmap, x+1, y+capHeight+1);
    }
  }
  
  public void drawMapButton() {
    pushStyle();
    noStroke();
    fill(127);
    rectMode(CORNER);
    rect(btnX, btnY, btnLen, btnLen);
    fill(0);
    textSize(10*scale);
    textAlign(CENTER, CENTER);
    
    text("MAP", btnX+btnLen/2, btnY+btnLen/2);
    popStyle();
  }
  
  private void switchDisplay()
  {
    isDisplay = !isDisplay;
  }
  
  public void update(float _x, float _y) {
    if (_x >= btnX && _x <= btnX+btnLen && _y >= btnY && _y <= btnY+btnLen) {
      switchDisplay();
      if (isDisplay)
      {
        ui.getSearchWindow().setNotDisplay();
      }
    }
    else {
      if (isDisplay && _x >= x && _x <= x + w && _y >= y+capHeight && _y <= y+capHeight + winHeight)
      {
        float xx = _x - x;
        float yy = _y - (y + capHeight);
        
        //float xx = map(_x, x, x+w, 0, 4399);
        //float yy = map(_y, y+capHeight, y+capHeight+winHeight, 0, 2233);
        
        int loc = (int)xx + (int)yy*(int)(w-1);
        float r = red(worldmap.pixels[loc]);
        float g = green(worldmap.pixels[loc]);
        float b = blue(worldmap.pixels[loc]);
        println("(r, g, b): " + "("+ r + ", " + g + ", " + b + ")");
        int region = -11;
        if (r == 254) {
          if (b == 191) {
            region = RUS;
          } else if (b == 63) {
            region = AFRI;
          } else if (b == 0) {
            region = MID;
          }
        } else if (r == 236) {
            region = N_AME;
        } else if (r == 127) {
          region = EURO;
        } else if (r == 169) {
          region = S_AME;
        } else if (r == 0) {
          region = ASIA;
        }
        ui.getCountryList().updateByMap(region);
        println("region: " +region);
        if (region != -11) {
          setNotDisplay();
        }
      }
    }
  }
  
  public void setNotDisplay()
  {
    isDisplay = false;
  }
  
  public boolean getIsDisplay()
  {
    return isDisplay;
  }
}
