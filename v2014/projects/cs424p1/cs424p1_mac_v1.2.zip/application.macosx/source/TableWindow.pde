class TableWindow {

  float x;
  float y;

  float lineW;
  float lineH;

  float btnX;
  float btnY;
  float btnLen;

  boolean isDisplay;

  int colCount;
  int rowCount;

  String[] txt;

  TableButton pageBtn;

  TableWindow(float _x, float _y, float _w, float _h, float bx, float by, float bl, float pbx, float pby, float pbh, float _diff) {
    x = _x;
    y = _y;
    lineW = _w;
    lineH = _h;

    btnX = bx;
    btnY = by;
    btnLen = bl;

    pageBtn = new TableButton(pbx, pby, pbh, _diff);

    isDisplay = false;
    colCount = 12;
    rowCount = DATA_SET_COUNT+1;

    txt = new String[] {
      "Ener Prod", "Ener Use", "Ener Use Per", "CO2 Emit", "CO2 Emit Per", "Renew Elec Prod"
    };
  }

  public boolean getIsDisplay() {
    return isDisplay;
  }

  public void render() {
    renderButton();
    if (isDisplay) {
      pushStyle();
      noFill();
      //strokeWeight(scale);
      stroke(0);
      rectMode(CORNER);

      //table
      rect(x, y, lineW * colCount, lineH * rowCount);

      //horizontal
      for (int i=1;i<rowCount;i++)
      {
        line(x, y+lineH*i, x+lineW*colCount, y+lineH*i);
      }

      //vertical
      for (int i=colCount-10;i<colCount;i++)
      {
        line(x+lineW*i, y, x+lineW*i, y + lineH*rowCount);
      }
      // end of table

      fill(0);
      textAlign(CENTER, CENTER);
      //title
      for (int i=colCount-10;i<colCount;i++)
      {
        text(1980+i-colCount+10+10*pageBtn.getPage(), x+lineW*(i+0.5), y+lineH*0.5);
      }

      // end of title

      // content

      if (ui.getDisplayMode() == ONE_COUNTRY_MODE) {

        textAlign(LEFT, CENTER);
        for (int i=rowCount-DATA_SET_COUNT;i<rowCount;i++)
        {
          text(ui.getDataSelector(i-rowCount+DATA_SET_COUNT).getTxt(), x+2*scale, y+lineH*(i+0.5));
          //text(txt[i-rowCount+6], x+scale,y+lineH*(i+0.5));
        }

        textAlign(RIGHT, CENTER);
        for (int i=rowCount-DATA_SET_COUNT;i<rowCount;i++)
        {
          for (int j=colCount-10;j<colCount;j++)
          {
            int colll = j-colCount+10 + pageBtn.getPage()*10;
            if (dataSets[i+DATA_SET_COUNT-rowCount].getData().isValid(currentRow[0], colll)) {
              text(nf(dataSets[i+DATA_SET_COUNT-rowCount].getData().getFloat(currentRow[0], colll), 0, 4), x+lineW*(j+1)-2*scale, y+lineH*(i+0.5));
            }
          }
        }
      } 
      else {

        textAlign(LEFT, CENTER);
        for (int i=rowCount-DATA_SET_COUNT;i<rowCount;i++)
        {
          if (currentDisplay[i-rowCount+DATA_SET_COUNT] == true) {
            text(countryNames[currentRow[i-rowCount+DATA_SET_COUNT]], x+2*scale, y+lineH*(i+0.5));
          }
        }

        textAlign(RIGHT, CENTER);
        int tab = 0;
        while (tab<DATA_SET_COUNT && ui.getDataSelector(tab).getCheck() == false) tab++;
        if (tab < DATA_SET_COUNT) { 
          for (int i=rowCount-DATA_SET_COUNT;i<rowCount;i++)
          {
            if (currentDisplay[i-rowCount+DATA_SET_COUNT] == true) {

              for (int j=colCount-10;j<colCount;j++)
              {
                int colll = j-colCount+10 + pageBtn.getPage()*10;
                if (dataSets[tab].getData().isValid(currentRow[i-rowCount+DATA_SET_COUNT], colll)) {
                  text(nf(dataSets[tab].getData().getFloat(currentRow[i-rowCount+DATA_SET_COUNT], colll), 0, 4), x+lineW*(j+1)-2*scale, y+lineH*(i+0.5));
                }
              }
            }
          }
        }
      }
      // end of content

      popStyle();

      pageBtn.render();
    }
  }

  private void renderButton() {
    pushStyle();
    noStroke();
    fill(127);
    rectMode(CORNER);
    rect(btnX, btnY, btnLen, btnLen);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(10*scale);
    text("RAW\nDATA", btnX+btnLen/2, btnY+btnLen/2);
    popStyle();
  }

  public void updateButton(float _x, float _y) {
    if (_x >= btnX && _x <= btnX + btnLen && _y >= btnY && _y <= btnY + btnLen) {
      switchDisplay();
    }
  }

  public void switchDisplay() {
    isDisplay = !isDisplay;
  }

  public void updatePage(float _x, float _y) {
    pageBtn.update(_x, _y);
  }
}

