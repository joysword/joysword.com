final float KEYBOARD_X = 20*scale;
final float KEYBOARD_Y = 45*scale;

class SearchWindow {
  float x;
  float y;
  float capHeight;
  float w;
  float winHeight;
  
  String caption;
  
  float btnX;
  float btnY;
  float btnLen;

  //Button closeButton;

  Keyboard keyboard;

  boolean isDisplay;
  
  String searchKey;

  SearchWindow(float _x, float _y, float wid, String cap, float cH, float wH, float bx, float by, float bl) {
    x = _x;
    y = _y;
    w = wid;
    caption = cap;
    capHeight = cH;
    winHeight = wH;

    keyboard = new Keyboard(x+KEYBOARD_X, y+capHeight + KEYBOARD_Y); 
    
    btnX = bx;
    btnY = by;
    btnLen = bl;

    isDisplay = false;
    searchKey = "";
  }

  public void render() {
    drawSearchButton();
    if (isDisplay) {
      pushStyle();
      fill(202);
      stroke(0);
      rectMode(CORNER);
      rect(x, y, w, capHeight+winHeight);
      line(x, y+capHeight, x+w, y+capHeight);
      textAlign(CENTER, CENTER);
      fill(0);
      textSize(25*scale);
      text(caption, x+0.5*w, y+0.5*capHeight);
      popStyle();
      keyboard.render();
      renderSearchKey();
    }
  }
  
  public void drawSearchButton() {
    pushStyle();
    noStroke();
    fill(127);
    rectMode(CORNER);
    rect(btnX, btnY, btnLen, btnLen);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(10*scale);
    text("SEARCH", btnX+btnLen/2, btnY+btnLen/2);
    popStyle();
  }
  
  private void switchDisplay()
  {
    isDisplay = !isDisplay;
  }
  
  public void update(float _x, float _y) {
    if (_x >= btnX && _x <= btnX+btnLen && _y >= btnY && _y <= btnY+btnLen) {
      switchDisplay();
      if (isDisplay)
      {
        ui.getMapWindow().setNotDisplay();
        
        searchKey = "";
      }
    }
    else {
      if (isDisplay) {
        int index = keyboard.update(_x, _y);
        if (index == ZHONG) {
          // update country list
          ui.getCountryList().updateBySearch(searchKey);
          println("search key: " + searchKey);
          setNotDisplay();
          //setNotDisplay();
        } else if (index == WRONG) {
          if (searchKey!="") {
            searchKey = searchKey.substring(0,searchKey.length()-1);
          }
          println("search key: " + searchKey);
        } else if (index!=0) {
          searchKey = searchKey + String.valueOf((char)index);
          println("search key: " + searchKey);
        }
      }
    }
  }
  
  public void setNotDisplay()
  {
    isDisplay = false;
  }
  
  private void renderSearchKey() {
    pushStyle();
    fill(255);
    stroke(0);
    rectMode(CORNERS);
    rect(x+ KEYBOARD_X + keyboard.getKeyLen() * 0.3, y + capHeight + KEYBOARD_Y * 0.1, x + w - keyboard.getKeyLen() * 3, y + capHeight + KEYBOARD_Y * 0.9);
    
    fill(0);
    textSize(30*scale);
    textAlign(LEFT, CENTER);
    text(searchKey.toLowerCase(), x + KEYBOARD_X + keyboard.getKeyLen() * 0.5, y + capHeight+ KEYBOARD_Y * 0.3);
    
    popStyle();
  }
  
  public boolean getIsDisplay()
  {
    return isDisplay;
  }
}

